# Data Provenance

## sample_cube.stl
- **Type**: ASCII STL geometry file
- **Description**: Simple unit cube (1m × 1m × 1m) composed of 12 triangular facets
- **Origin**: SYNTHETIC — Self-created for testing purposes
- **Units**: Meters
- **Triangle count**: 12
- **File size**: ~1.5 KB

## sample_temperature.csv
- **Type**: ANSYS-style CSV temperature data
- **Description**: SYNTHETIC temperature distribution over a rectangular region
- **Origin**: SYNTHETIC — Self-created for testing purposes. NOT an actual ANSYS export.
- **Schema**: `node_id,x_m,y_m,z_m,temperature_C`
- **Units**: Positions in meters, temperatures in degrees Celsius
- **Node count**: 50
- **Temperature range**: 60.0°C to 100.0°C
- **File size**: ~1.2 KB

## Supported formats
- ASCII STL files only (binary STL is NOT supported)
- CSV files with exact column headers: `node_id,x_m,y_m,z_m,temperature_C`

## File-size limits
- STL files: Tested up to 10 MB (~200,000 triangles)
- CSV files: Tested up to 5 MB (~100,000 nodes)

