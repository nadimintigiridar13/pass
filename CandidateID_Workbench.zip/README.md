# UNIFIED ENGINEERING WORKBENCH
**PASS SCIENCE WORKS | R&D Internship Technical Assignment 2026–2027**  
*Full-Stack Engineering Dashboard & C++17 High-Performance Scientific Compute Core*

---

## 🚀 1-Click Standalone Execution (Windows 11 x64)

The submission includes a completely standalone, pre-built binary package:

1. **Double-click `Launch.exe`** (or `Launch.bat`) in the root directory.
2. The application starts the native C++17 REST backend on `http://localhost:8080` and automatically opens the engineering dashboard in your default browser.
3. **Zero prerequisites required**: No terminal commands, no PowerShell commands, no administrator rights, no Python, no Node.js, and no internet access are needed to run the standalone executable.

---

## 🏗️ Architecture Overview

The application satisfies all six core assignment tasks (A–F):

```
UnifiedEngineeringWorkbench/
├── Launch.exe                  # 1-Click Native C++ Launcher
├── Launch.bat                  # Batch launcher alternative
├── workbench_backend.exe       # Native C++17 HTTP REST API Server
├── libgcc_s_seh-1.dll          # Bundled GCC runtime dependency
├── libstdc++-6.dll             # Bundled C++ standard library
├── libwinpthread-1.dll         # POSIX thread library for Windows
├── CMakeLists.txt              # Standard CMake build configuration
├── backend/                    # C++17 Source Tree
│   ├── include/
│   │   ├── common/             # Types, Result<T>, Validation, Linear Algebra
│   │   ├── geometry/           # ASCII STL and CSV temperature parsers
│   │   ├── thermal/            # 1D Steady-State Thermal FEA solver
│   │   ├── performance/        # Multicore worker pool benchmark
│   │   ├── hardware/           # Microcontroller, FPGA, JTAG mock adapters
│   │   ├── backpropagation/   # Analytical gradients and training engine
│   │   ├── api/                # REST API endpoints (httplib & nlohmann/json)
│   │   └── httplib.h           # Lightweight header-only HTTP server
│   └── src/                    # C++17 Implementation files
├── frontend/                   # React + TypeScript + Vite + Tailwind Dashboard
│   ├── dist/                   # Production-built web assets (served directly by C++ backend)
│   └── src/                    # Pages, 3D Viewers (Three.js), and Charts (Recharts)
├── data/                       # Sample data files
│   ├── sample_cube.stl         # Verified ASCII STL (12 triangles)
│   ├── sample_temperature.csv  # ANSYS-style CSV (50 nodes)
│   └── PROVENANCE.md           # Dataset provenance & schema specification
├── tests/                      # Automated Verification Tests
│   └── test_workbench.cpp      # Unit & numerical tests (35/35 passing)
└── docs/                       # Technical reports & rubric evidence
    ├── TECHNICAL_REPORT.md
    ├── HANDWRITTEN_BACKPROP_GUIDE.md
    ├── AI_USE_LOG.md
    ├── OWNERSHIP_STATEMENT.md
    └── RUBRIC_SELF_ASSESSMENT.md
```

---

## 📋 Task Coverage Summary

| Task | Module | Implementation Details | Status |
|---|---|---|---|
| **A** | **Unified UI & One-Click Launch** | React + TypeScript dashboard with dark theme, sidebar navigation, parameter validation, real-time status indicators, and standalone `Launch.exe`. | **COMPLETE** |
| **B** | **CAD & Temperature 3D Visualization** | C++17 ASCII STL parser with Three.js orbit controls, fit-to-view, plus ANSYS-style CSV temperature viewer with colored 3D point cloud and node inspection. | **COMPLETE** |
| **C** | **1D Thermal FEA Solver** | Steady-state conduction: `-d/dx(kA dT/dx) = qA`. Tridiagonal Thomas solver, analytical solution comparison, midpoint error calculation, and mesh convergence study for N = 10, 20, 40, 80. | **COMPLETE** |
| **D** | **Multicore Benchmarking** | Bounded C++ standard thread pool (1–4 workers). Median of 5 repetitions with warm-up run. Strict numerical agreement check ($\Delta T \le 10^{-8}\,^\circ\text{C}$). Speedup & efficiency reporting. | **COMPLETE** |
| **E** | **Embedded Hardware Integration** | Microcontroller (ESP32), FPGA (Artix-7), and JTAG (J-Link) mock adapters. Interface table, block diagram, and recoverable fault injection demonstration. | **COMPLETE** |
| **F** | **Handwritten Backpropagation** | Regression network ($h = \tanh(wx+b)$, $\hat{y} = vh+c$). Chain-rule gradients, central finite-difference check ($\le 10^{-5}$ error), 100-step training loss curve, and 2-page handwritten calculation guide. | **COMPLETE** |

---

## 🛠️ CMake Source-Build Instructions

To build the C++ backend from source using CMake:

```powershell
# Prerequisites: CMake 3.16+ and a C++17 compiler (GCC/MinGW or MSVC)
mkdir build
cd build
cmake ..
cmake --build . --config Release

# Run tests
ctest --output-on-failure
```

---

## 🧪 Automated Testing

To run the standalone C++ verification test suite directly:

```powershell
tests\run_tests.exe
```

All 35 unit and numerical tests pass with zero failures.
