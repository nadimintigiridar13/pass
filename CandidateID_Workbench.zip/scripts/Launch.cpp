#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <iostream>
#include <string>
#include <chrono>
#include <thread>

int main() {
    std::cout << "=========================================================\n";
    std::cout << " UNIFIED ENGINEERING WORKBENCH - STANDALONE LAUNCHER     \n";
    std::cout << " PASS SCIENCE WORKS | R&D Internship 2026-2027           \n";
    std::cout << "=========================================================\n\n";
    std::cout << "Starting native C++17 REST backend...\n";

    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    char cmd[] = "workbench_backend.exe 8080";

    if (!CreateProcessA(
            NULL,
            cmd,
            NULL,
            NULL,
            FALSE,
            CREATE_NEW_CONSOLE,
            NULL,
            NULL,
            &si,
            &pi)) {
        std::cerr << "[ERROR] Failed to start workbench_backend.exe (Error code " << GetLastError() << ")\n";
        std::cerr << "Ensure workbench_backend.exe and required DLLs are present.\n";
        std::cout << "\nPress Enter to exit...";
        std::cin.get();
        return 1;
    }

    std::cout << "[OK] C++ Backend started (PID: " << pi.dwProcessId << ")\n";
    std::cout << "Opening Unified Engineering Workbench dashboard at http://localhost:8080 ...\n";

    // Wait a brief moment for socket to bind
    std::this_thread::sleep_for(std::chrono::milliseconds(1200));

    // Open browser
    ShellExecuteA(NULL, "open", "http://localhost:8080", NULL, NULL, SW_SHOWNORMAL);

    std::cout << "\n---------------------------------------------------------\n";
    std::cout << " Application is running!\n";
    std::cout << " Dashboard: http://localhost:8080\n";
    std::cout << " Backend REST API: http://localhost:8080/api/health\n";
    std::cout << " Close this window or press Ctrl+C to terminate application.\n";
    std::cout << "---------------------------------------------------------\n\n";

    // Wait for backend process to exit
    WaitForSingleObject(pi.hProcess, INFINITE);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    std::cout << "Unified Engineering Workbench terminated.\n";
    return 0;
}
