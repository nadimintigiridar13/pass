import subprocess
import sys
import os
import time

def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    mingw_bin = os.path.join(root, "tools2", "mingw64", "bin")
    os.environ["PATH"] = mingw_bin + os.pathsep + os.environ.get("PATH", "")
    
    gpp = os.path.join(mingw_bin, "g++.exe")
    if not os.path.exists(gpp):
        gpp = "g++"
        
    srcs = [
        "backend/src/common/csv_utils.cpp",
        "backend/src/common/linear_algebra.cpp",
        "backend/src/common/validation.cpp",
        "backend/src/geometry/stl_parser.cpp",
        "backend/src/geometry/csv_temperature_parser.cpp",
        "backend/src/thermal/thermal_solver.cpp",
        "backend/src/performance/batch_generator.cpp",
        "backend/src/performance/benchmark.cpp",
        "backend/src/hardware/microcontroller_adapter.cpp",
        "backend/src/hardware/fpga_adapter.cpp",
        "backend/src/hardware/jtag_adapter.cpp",
        "backend/src/backpropagation/neural_network.cpp",
        "backend/src/api/server.cpp",
        "backend/src/main.cpp"
    ]
    
    obj_dir = os.path.join(root, "build", "obj")
    os.makedirs(obj_dir, exist_ok=True)
    
    objs = []
    print(f"Building Unified Engineering Workbench C++ Backend using {gpp}...")
    start_time = time.time()
    
    for src in srcs:
        src_path = os.path.join(root, src)
        name = os.path.splitext(os.path.basename(src))[0] + ".o"
        obj_path = os.path.join(obj_dir, name)
        objs.append(obj_path)
        
        cmd = [
            gpp, "-std=c++17", "-O2",
            "-I" + os.path.join(root, "backend", "include"),
            "-c", src_path,
            "-o", obj_path
        ]
        
        print(f"  Compiling {src}...", flush=True)
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if res.returncode != 0:
            print(f"FAILED: {src}")
            print(res.stderr)
            sys.exit(1)
            
    exe_path = os.path.join(root, "workbench_backend.exe")
    link_cmd = [
        gpp, "-std=c++17", "-O2"
    ] + objs + [
        "-lws2_32", "-lpthread",
        "-o", exe_path
    ]
    
    print(f"Linking executable {exe_path}...")
    res = subprocess.run(link_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        print("Linking failed!")
        print(res.stderr)
        sys.exit(1)
        
    elapsed = time.time() - start_time
    print(f"SUCCESS! Built {exe_path} in {elapsed:.2f} seconds.")

if __name__ == "__main__":
    main()
