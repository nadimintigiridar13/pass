import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { GeometryPage } from './pages/GeometryPage';
import { ThermalPage } from './pages/ThermalPage';
import { PerformancePage } from './pages/PerformancePage';
import { HardwarePage } from './pages/HardwarePage';
import { BackpropagationPage } from './pages/BackpropagationPage';

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<GeometryPage />} />
          <Route path="thermal" element={<ThermalPage />} />
          <Route path="performance" element={<PerformancePage />} />
          <Route path="hardware" element={<HardwarePage />} />
          <Route path="backprop" element={<BackpropagationPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;
