import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Box, 
  Flame, 
  Cpu, 
  CircuitBoard, 
  BrainCircuit, 
  Activity,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface SidebarProps {
  backendConnected: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ backendConnected }) => {
  const navItems = [
    { to: '/', label: 'Geometry & Visuals', icon: Box },
    { to: '/thermal', label: 'Thermal Analysis (FEA)', icon: Flame },
    { to: '/performance', label: 'Multicore Performance', icon: Cpu },
    { to: '/hardware', label: 'Embedded Hardware', icon: CircuitBoard },
    { to: '/backprop', label: 'Backpropagation', icon: BrainCircuit },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none">
      <div>
        {/* Brand */}
        <div className="h-16 flex items-center px-6 border-b border-slate-800 gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">
            UEW
          </div>
          <div>
            <h1 className="text-sm font-semibold text-white tracking-wide">Workbench</h1>
            <p className="text-[10px] text-slate-400 font-mono">PASS SCIENCE WORKS</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">
            Modules
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`
                }
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Backend Status footer */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/40">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 flex items-center gap-2">
            <Activity size={14} className="text-slate-500" />
            C++ Backend
          </span>
          {backendConnected ? (
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full text-[11px]">
              <CheckCircle size={12} />
              Port 8080
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-rose-400 font-medium bg-rose-950/60 border border-rose-800/60 px-2 py-0.5 rounded-full text-[11px]">
              <XCircle size={12} />
              Offline
            </span>
          )}
        </div>
        <div className="mt-2 text-[10px] text-slate-400 flex justify-between">
          <span>Target: Win11 x64</span>
          <span>R&D 2026-27</span>
        </div>
      </div>
    </aside>
  );
};
