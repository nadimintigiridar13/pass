import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { apiService } from '../services/api';

export const Layout: React.FC = () => {
  const [backendConnected, setBackendConnected] = useState<boolean>(false);

  useEffect(() => {
    const checkConnection = async () => {
      try {
        await apiService.checkHealth();
        setBackendConnected(true);
      } catch (err) {
        setBackendConnected(false);
      }
    };

    checkConnection();
    const interval = setInterval(checkConnection, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      <Sidebar backendConnected={backendConnected} />
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <header className="h-14 border-b border-slate-800 bg-slate-900/60 px-8 flex items-center justify-between shrink-0 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-blue-900/50 text-blue-300 border border-blue-700/50">
              R&D INTERNSHIP 2026–2027
            </span>
            <span className="text-xs text-slate-400">
              PASS SCIENCE WORKS • Unified Engineering Workbench
            </span>
          </div>
          <div className="text-xs text-slate-400">
            Native C++17 Core • Strict Numerical Verification
          </div>
        </header>

        <div className="p-8 flex-1">
          <Outlet />
        </div>
      </main>
    </div>
  );
};
