export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface Triangle {
  normal: [number, number, number];
  vertices: [number, number, number][];
}

export interface BoundingBox {
  min: [number, number, number];
  max: [number, number, number];
}

export interface StlData {
  solid_name: string;
  triangle_count: number;
  file_size: number;
  bounding_box: BoundingBox;
  triangles: Triangle[];
}

export interface TemperatureNode {
  node_id: number;
  x: number;
  y: number;
  z: number;
  temperature: number;
}

export interface TemperatureData {
  node_count: number;
  min_temperature: number;
  max_temperature: number;
  bounding_box: BoundingBox;
  nodes: TemperatureNode[];
}

export interface ThermalNodeResult {
  position: number;
  temperature: number;
  exact_temperature: number;
}

export interface ThermalMidpointResult {
  position: number;
  fe_temp: number;
  exact_temp: number;
  error: number;
}

export interface ThermalParams {
  L: number;
  A: number;
  k: number;
  q: number;
  T_left: number;
  T_right: number;
  num_elements: number;
}

export interface ThermalResult {
  num_elements: number;
  max_midpoint_error: number;
  parameters: ThermalParams;
  nodes: ThermalNodeResult[];
  midpoints: ThermalMidpointResult[];
}

export interface ConvergencePoint {
  num_elements: number;
  element_size: number;
  max_midpoint_error: number;
}

export interface ConvergenceResult {
  convergence: ConvergencePoint[];
}

export interface BenchmarkRun {
  workers: number;
  serial_time_ms: number;
  parallel_time_ms: number;
  speedup: number;
  efficiency: number;
  max_disagreement: number;
  results_agree: boolean;
}

export interface BenchmarkResult {
  num_cases: number;
  mesh_size: number;
  hardware_info: string;
  logical_cpus: number;
  benchmark_runs: BenchmarkRun[];
}

export interface DeviceCapabilities {
  name: string;
  firmware_version: string;
  supported_protocols: string[];
  max_sample_rate_hz: number;
  adc_resolution_bits: number;
  gpio_pins: number;
}

export interface DeviceTelemetry {
  cpu_usage_percent: number;
  temperature_celsius: number;
  voltage_v: number;
  current_ma: number;
  uptime_seconds: number;
  free_memory_bytes: number;
  status_message: string;
}

export interface HardwareDevice {
  id: string;
  name: string;
  type: string;
  status: 'Disconnected' | 'Connecting' | 'Connected' | 'Error';
  capabilities?: DeviceCapabilities;
  telemetry?: DeviceTelemetry;
}

export interface BackpropForwardResult {
  h: number;
  y_hat: number;
  loss: number;
  error: number;
  parameters: {
    w: number;
    b: number;
    v: number;
    c: number;
    x: number;
    y: number;
    alpha: number;
  };
}

export interface GradientValue {
  analytical: number;
  numerical: number;
  abs_error: number;
}

export interface BackpropVerificationResult {
  passed: boolean;
  max_error: number;
  tolerance: number;
  epsilon: number;
  gradients: {
    w: GradientValue;
    b: GradientValue;
    v: GradientValue;
    c: GradientValue;
  };
}

export interface TrainingStep {
  step: number;
  loss: number;
  y_hat: number;
  w: number;
  b: number;
  v: number;
  c: number;
}

export interface BackpropTrainingResult {
  history: TrainingStep[];
  final_loss: number;
  final_params: {
    w: number;
    b: number;
    v: number;
    c: number;
  };
  gradient_verification_passed: boolean;
}
