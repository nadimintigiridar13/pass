import axios from 'axios';
import type {
  StlData,
  TemperatureData,
  ThermalResult,
  ConvergenceResult,
  BenchmarkResult,
  HardwareDevice,
  DeviceTelemetry,
  BackpropForwardResult,
  BackpropVerificationResult,
  BackpropTrainingResult,
} from '../types';

const API_BASE = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 60000,
});

export const apiService = {
  // Health
  checkHealth: async () => {
    const res = await api.get('/health');
    return res.data;
  },

  getSystemInfo: async () => {
    const res = await api.get('/system/info');
    return res.data;
  },

  // Geometry (Task B)
  parseStl: async (fileContent: string): Promise<StlData> => {
    const res = await api.post('/geometry/parse-stl', fileContent, {
      headers: { 'Content-Type': 'text/plain' },
    });
    return res.data;
  },

  parseTemperatureCsv: async (fileContent: string): Promise<TemperatureData> => {
    const res = await api.post('/geometry/parse-csv', fileContent, {
      headers: { 'Content-Type': 'text/plain' },
    });
    return res.data;
  },

  // Thermal FEA (Task C)
  solveThermal: async (params: {
    L: number;
    A: number;
    k: number;
    q: number;
    T_left: number;
    T_right: number;
    num_elements: number;
  }): Promise<ThermalResult> => {
    const res = await api.post('/thermal/solve', params);
    return res.data;
  },

  runConvergenceStudy: async (params?: Partial<{
    L: number;
    A: number;
    k: number;
    q: number;
    T_left: number;
    T_right: number;
  }>): Promise<ConvergenceResult> => {
    const res = await api.post('/thermal/convergence', params || {});
    return res.data;
  },

  // Performance (Task D)
  runBenchmark: async (params: {
    num_cases: number;
    mesh_size: number;
    max_workers: number;
  }): Promise<BenchmarkResult> => {
    const res = await api.post('/performance/benchmark', params);
    return res.data;
  },

  // Hardware (Task E)
  getDevices: async (): Promise<HardwareDevice[]> => {
    const res = await api.get('/hardware/devices');
    return res.data;
  },

  discoverDevice: async (id: string) => {
    const res = await api.post(`/hardware/${id}/discover`);
    return res.data;
  },

  connectDevice: async (id: string) => {
    const res = await api.post(`/hardware/${id}/connect`);
    return res.data;
  },

  disconnectDevice: async (id: string) => {
    const res = await api.post(`/hardware/${id}/disconnect`);
    return res.data;
  },

  getDeviceTelemetry: async (id: string): Promise<DeviceTelemetry> => {
    const res = await api.get(`/hardware/${id}/telemetry`);
    return res.data;
  },

  // Backpropagation (Task F)
  runBackpropForward: async (params?: any): Promise<BackpropForwardResult> => {
    const res = await api.post('/backprop/forward', params || {});
    return res.data;
  },

  runBackpropVerify: async (params?: any): Promise<BackpropVerificationResult> => {
    const res = await api.post('/backprop/verify', params || {});
    return res.data;
  },

  runBackpropTrain: async (params?: { num_steps?: number; alpha?: number }): Promise<BackpropTrainingResult> => {
    const res = await api.post('/backprop/train', params || {});
    return res.data;
  },
};
