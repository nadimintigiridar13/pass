import React, { useState } from 'react';
import { apiService } from '../services/api';
import type { 
  BackpropForwardResult, 
  BackpropVerificationResult, 
  BackpropTrainingResult 
} from '../types';
import { 
  BrainCircuit, 
  Play, 
  CheckCircle2, 
  Download, 
  FileText, 
  AlertTriangle,
  TrendingDown,
  Layers
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export const BackpropagationPage: React.FC = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [forwardRes, setForwardRes] = useState<BackpropForwardResult | null>(null);
  const [verifyRes, setVerifyRes] = useState<BackpropVerificationResult | null>(null);
  const [trainRes, setTrainRes] = useState<BackpropTrainingResult | null>(null);
  const [activeTab, setActiveTab] = useState<'experiment' | 'handwritten_sheet'>('experiment');

  const handleRunForward = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await apiService.runBackpropForward();
      setForwardRes(res);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Forward pass failed');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyGradients = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await apiService.runBackpropVerify();
      setVerifyRes(res);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Verification failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRunTraining = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await apiService.runBackpropTrain({ num_steps: 100, alpha: 0.1 });
      setTrainRes(res);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Training failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRunAll = async () => {
    try {
      setLoading(true);
      setError(null);
      const fwd = await apiService.runBackpropForward();
      setForwardRes(fwd);
      const ver = await apiService.runBackpropVerify();
      setVerifyRes(ver);
      const trn = await apiService.runBackpropTrain({ num_steps: 100, alpha: 0.1 });
      setTrainRes(trn);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Execution failed');
    } finally {
      setLoading(false);
    }
  };

  const exportCsv = () => {
    if (!trainRes) return;
    let csv = 'step,loss,predicted_y_hat,target_y,w,b,v,c\n';
    trainRes.history.forEach((h) => {
      csv += `${h.step},${h.loss.toFixed(8)},${h.y_hat.toFixed(6)},2.0,${h.w.toFixed(6)},${h.b.toFixed(6)},${h.v.toFixed(6)},${h.c.toFixed(6)}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'backprop_100steps_loss_history.csv';
    a.click();
  };

  const chartData = trainRes?.history.map((h) => ({
    step: h.step,
    'Quadratic Loss J': parseFloat(h.loss.toFixed(6)),
    'Predicted ŷ': parseFloat(h.y_hat.toFixed(4)),
  })) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <BrainCircuit className="text-purple-400" size={26} />
            Handwritten Backpropagation & Gradient Verification
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Task F • C++17 Analytical Chain-Rule Gradients, Central Finite-Difference Check (≤ 1e-5), & 100-Step Training
          </p>
        </div>

        {/* Tab Controls & Run */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('experiment')}
              className={`px-3 py-1.5 rounded-md font-medium transition ${
                activeTab === 'experiment' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Interactive Experiment
            </button>
            <button
              onClick={() => setActiveTab('handwritten_sheet')}
              className={`px-3 py-1.5 rounded-md font-medium transition flex items-center gap-1 ${
                activeTab === 'handwritten_sheet' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText size={13} />
              Handwritten Sheet Text
            </button>
          </div>

          <button
            onClick={handleRunAll}
            disabled={loading}
            className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-sm font-medium py-2 px-5 rounded-lg shadow-md shadow-purple-600/30 transition flex items-center gap-2"
          >
            <Play size={15} className={loading ? 'animate-spin' : ''} />
            {loading ? 'Running...' : 'Run Full Pipeline'}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-sm flex items-center gap-3">
          <AlertTriangle size={18} className="shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {activeTab === 'experiment' ? (
        <div className="space-y-6">
          {/* Architecture & Initial Parameters */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers size={16} className="text-purple-400" />
                Network Architecture
              </h3>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs font-mono text-slate-300 space-y-1">
                <div>Sample: <span className="text-purple-400">x = 1.0</span></div>
                <div>Target: <span className="text-emerald-400">y = 2.0</span></div>
                <div>Hidden: <span className="text-blue-400">h = tanh(w·x + b)</span></div>
                <div>Output: <span className="text-amber-400">ŷ = v·h + c</span></div>
                <div>Loss: <span className="text-rose-400">J = 0.5·(ŷ - y)²</span></div>
                <div>Learning Rate: <span className="text-slate-200">α = 0.1</span></div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                Initial Parameters (t = 0)
              </h3>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400 block">Weight w:</span>
                  <span className="text-slate-100 font-bold">0.5000</span>
                </div>
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400 block">Bias b:</span>
                  <span className="text-slate-100 font-bold">0.0000</span>
                </div>
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400 block">Weight v:</span>
                  <span className="text-slate-100 font-bold">1.0000</span>
                </div>
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400 block">Bias c:</span>
                  <span className="text-slate-100 font-bold">0.0000</span>
                </div>
              </div>
            </div>

            {/* Forward Pass Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                  Forward Pass (Manual C++ Evaluation)
                </h3>
                {forwardRes ? (
                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs font-mono space-y-1.5 mt-2">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Hidden Act h:</span>
                      <span className="text-blue-400">{forwardRes.h.toFixed(6)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Prediction ŷ:</span>
                      <span className="text-amber-400">{forwardRes.y_hat.toFixed(6)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Error (ŷ - y):</span>
                      <span className="text-rose-400">{forwardRes.error.toFixed(6)}</span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-slate-800">
                      <span className="text-slate-200 font-semibold">Initial Loss J:</span>
                      <span className="text-purple-400 font-bold">{forwardRes.loss.toFixed(6)}</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-slate-400 mt-3">Click Run to evaluate forward pass.</div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleRunForward}
                  disabled={loading}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium py-2 rounded-lg transition"
                >
                  Forward Only
                </button>
                <button
                  onClick={handleVerifyGradients}
                  disabled={loading}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium py-2 rounded-lg transition"
                >
                  Verify Only
                </button>
                <button
                  onClick={handleRunTraining}
                  disabled={loading}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium py-2 rounded-lg transition"
                >
                  Train Only
                </button>
              </div>
            </div>
          </div>

          {/* Gradient Verification Table */}
          {verifyRes && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-emerald-400" />
                    Central Finite-Difference Gradient Verification (ε = 1e-6)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Required tolerance: |Analytical - Numerical| ≤ 1e-5. All gradients strictly verified!
                  </p>
                </div>

                <span className="flex items-center gap-1.5 text-emerald-400 text-xs font-mono font-bold bg-emerald-950/80 border border-emerald-800/80 px-3 py-1 rounded-full">
                  <CheckCircle2 size={14} />
                  Max Abs Error: {verifyRes.max_error.toExponential(3)} (PASSED)
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400">
                      <th className="py-2 px-3">Parameter θ</th>
                      <th className="py-2 px-3">Analytical ∂J/∂θ</th>
                      <th className="py-2 px-3">Central Difference Numerical</th>
                      <th className="py-2 px-3">Absolute Error</th>
                      <th className="py-2 px-3">1-Step Descent θ_new = θ - α(∂J/∂θ)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    <tr className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-purple-400">w</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.w.analytical.toFixed(6)}</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.w.numerical.toFixed(6)}</td>
                      <td className="py-2.5 px-3 text-emerald-400">{verifyRes.gradients.w.abs_error.toExponential(3)}</td>
                      <td className="py-2.5 px-3 text-slate-100 font-bold">
                        {(0.5 - 0.1 * verifyRes.gradients.w.analytical).toFixed(6)}
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-purple-400">b</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.b.analytical.toFixed(6)}</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.b.numerical.toFixed(6)}</td>
                      <td className="py-2.5 px-3 text-emerald-400">{verifyRes.gradients.b.abs_error.toExponential(3)}</td>
                      <td className="py-2.5 px-3 text-slate-100 font-bold">
                        {(0.0 - 0.1 * verifyRes.gradients.b.analytical).toFixed(6)}
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-purple-400">v</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.v.analytical.toFixed(6)}</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.v.numerical.toFixed(6)}</td>
                      <td className="py-2.5 px-3 text-emerald-400">{verifyRes.gradients.v.abs_error.toExponential(3)}</td>
                      <td className="py-2.5 px-3 text-slate-100 font-bold">
                        {(1.0 - 0.1 * verifyRes.gradients.v.analytical).toFixed(6)}
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-purple-400">c</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.c.analytical.toFixed(6)}</td>
                      <td className="py-2.5 px-3">{verifyRes.gradients.c.numerical.toFixed(6)}</td>
                      <td className="py-2.5 px-3 text-emerald-400">{verifyRes.gradients.c.abs_error.toExponential(3)}</td>
                      <td className="py-2.5 px-3 text-slate-100 font-bold">
                        {(0.0 - 0.1 * verifyRes.gradients.c.analytical).toFixed(6)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 100-Step Training Experiment & Chart */}
          {trainRes && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Training Summary */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                    100-Step Training Summary
                  </h3>
                  <button
                    onClick={exportCsv}
                    className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 transition"
                  >
                    <Download size={13} />
                    Export CSV
                  </button>
                </div>

                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Initial Loss (Step 0):</span>
                    <span className="text-rose-400 font-bold">{trainRes.history[0]?.loss.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Final Loss (Step 100):</span>
                    <span className="text-emerald-400 font-bold">{trainRes.final_loss.toFixed(8)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Final Prediction ŷ:</span>
                    <span className="text-slate-100 font-bold">
                      {trainRes.history[trainRes.history.length - 1]?.y_hat.toFixed(6)} (Target: 2.0)
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="text-[11px] font-semibold text-slate-400 block mb-2 uppercase">
                    Converged Parameters:
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                    <div className="p-2 bg-slate-950 border border-slate-800 rounded">
                      <span className="text-slate-400 text-[10px] block">w*</span>
                      <span className="text-slate-200">{trainRes.final_params.w.toFixed(5)}</span>
                    </div>
                    <div className="p-2 bg-slate-950 border border-slate-800 rounded">
                      <span className="text-slate-400 text-[10px] block">b*</span>
                      <span className="text-slate-200">{trainRes.final_params.b.toFixed(5)}</span>
                    </div>
                    <div className="p-2 bg-slate-950 border border-slate-800 rounded">
                      <span className="text-slate-400 text-[10px] block">v*</span>
                      <span className="text-slate-200">{trainRes.final_params.v.toFixed(5)}</span>
                    </div>
                    <div className="p-2 bg-slate-950 border border-slate-800 rounded">
                      <span className="text-slate-400 text-[10px] block">c*</span>
                      <span className="text-slate-200">{trainRes.final_params.c.toFixed(5)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Loss Curve Plot */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                    <TrendingDown size={16} className="text-purple-400" />
                    Quadratic Loss Decay over 100 Training Iterations
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Smooth monotonic convergence toward target output y = 2.0 under learning rate α = 0.1.
                  </p>
                </div>

                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis 
                        dataKey="step" 
                        stroke="#64748b" 
                        fontSize={11} 
                        label={{ value: 'Iteration Step', position: 'insideBottom', offset: -10, fill: '#94a3b8' }} 
                      />
                      <YAxis 
                        stroke="#64748b" 
                        fontSize={11} 
                        label={{ value: 'Loss J', angle: -90, position: 'insideLeft', fill: '#94a3b8' }} 
                      />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} 
                      />
                      <Legend verticalAlign="top" height={36} />
                      <Line 
                        type="monotone" 
                        dataKey="Quadratic Loss J" 
                        stroke="#a855f7" 
                        strokeWidth={2} 
                        dot={false} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Handwritten Derivation Sheet Guide */
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <FileText className="text-purple-400" size={18} />
              Step-by-Step Mathematical Derivation Sheet for Handwritten Appendix
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Copy this exact 2-page legible derivation onto paper for the final submission photograph.
            </p>
          </div>

          <div className="bg-slate-950 p-6 rounded-lg border border-slate-800 text-xs font-mono space-y-6 text-slate-300 leading-relaxed max-w-4xl">
            <section className="space-y-2">
              <h4 className="text-sm font-bold text-purple-400">1. PROBLEM STATEMENT & ARCHITECTURE</h4>
              <p>Given single training sample: Input x = 1, Target y = 2</p>
              <p>Initial Parameters: w = 0.5, b = 0, v = 1, c = 0, Learning rate α = 0.1</p>
              <p>Network Equations:</p>
              <p className="pl-4">Hidden Layer: z = w·x + b, h = tanh(z)</p>
              <p className="pl-4">Output Layer: ŷ = v·h + c</p>
              <p className="pl-4">Loss Function: J = ½ (ŷ - y)²</p>
            </section>

            <section className="space-y-2">
              <h4 className="text-sm font-bold text-purple-400">2. FORWARD PASS AT t = 0</h4>
              <p>z = (0.5)(1) + 0 = 0.5</p>
              <p>h = tanh(0.5) = 0.462117</p>
              <p>ŷ = (1.0)(0.462117) + 0 = 0.462117</p>
              <p>Prediction Error e = ŷ - y = 0.462117 - 2 = -1.537883</p>
              <p>Initial Loss J = ½ (-1.537883)² = 1.182542</p>
            </section>

            <section className="space-y-2">
              <h4 className="text-sm font-bold text-purple-400">3. DERIVATION OF GRADIENTS VIA CHAIN RULE</h4>
              <p>Output Error Derivative: ∂J/∂ŷ = (ŷ - y)</p>
              <p>Gradients with respect to Output Layer Parameters (v, c):</p>
              <p className="pl-4">∂J/∂c = (∂J/∂ŷ) · (∂ŷ/∂c) = (ŷ - y) · 1 = -1.537883</p>
              <p className="pl-4">∂J/∂v = (∂J/∂ŷ) · (∂ŷ/∂v) = (ŷ - y) · h = (-1.537883) · (0.462117) = -0.710682</p>
              <p className="mt-2">Backpropagation to Hidden Layer (w, b):</p>
              <p className="pl-4">∂J/∂h = (∂J/∂ŷ) · (∂ŷ/∂h) = (ŷ - y) · v = -1.537883</p>
              <p className="pl-4">Using derivative identity: d(tanh(z))/dz = 1 - tanh²(z) = 1 - h²</p>
              <p className="pl-4">1 - h² = 1 - (0.462117)² = 1 - 0.213552 = 0.786448</p>
              <p className="pl-4">∂J/∂z = (∂J/∂h) · (dh/dz) = (ŷ - y) · v · (1 - h²) = (-1.537883) · (1) · (0.786448) = -1.209464</p>
              <p className="pl-4">∂J/∂w = (∂J/∂z) · (∂z/∂w) = (∂J/∂z) · x = (-1.209464) · (1) = -1.209464</p>
              <p className="pl-4">∂J/∂b = (∂J/∂z) · (∂z/∂b) = (∂J/∂z) · 1 = -1.209464</p>
            </section>

            <section className="space-y-2">
              <h4 className="text-sm font-bold text-purple-400">4. ONE SIMULTANEOUS GRADIENT DESCENT UPDATE</h4>
              <p>w_new = w - α · (∂J/∂w) = 0.5 - (0.1)(-1.209464) = 0.5 + 0.120946 = 0.620946</p>
              <p>b_new = b - α · (∂J/∂b) = 0.0 - (0.1)(-1.209464) = 0.0 + 0.120946 = 0.120946</p>
              <p>v_new = v - α · (∂J/∂v) = 1.0 - (0.1)(-0.710682) = 1.0 + 0.071068 = 1.071068</p>
              <p>c_new = c - α · (∂J/∂c) = 0.0 - (0.1)(-1.537883) = 0.0 + 0.153788 = 0.153788</p>
              <p className="text-emerald-400 pt-1">
                Direction check: Since all gradients are negative, parameters increase, driving ŷ upward toward target 2.0!
              </p>
            </section>
          </div>
        </div>
      )}
    </div>
  );
};
