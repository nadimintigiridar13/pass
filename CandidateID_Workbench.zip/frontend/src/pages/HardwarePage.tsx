import React, { useState, useEffect } from 'react';
import { apiService } from '../services/api';
import type { HardwareDevice } from '../types';
import { 
  CircuitBoard, 
  Search, 
  Power, 
  PowerOff, 
  Activity, 
  AlertTriangle, 
  ShieldCheck, 
  Cpu, 
  RefreshCw
} from 'lucide-react';

export const HardwarePage: React.FC = () => {
  const [devices, setDevices] = useState<HardwareDevice[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchDevices = async () => {
    try {
      setLoading(true);
      const devs = await apiService.getDevices();
      setDevices(devs);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to load hardware adapters');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDevices();
    // Poll telemetry if any connected
    const interval = setInterval(() => {
      fetchDevices();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleDiscover = async (id: string) => {
    try {
      setActionLoading(id);
      setErrorMsg(null);
      await apiService.discoverDevice(id);
      await fetchDevices();
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message || 'Discovery failed');
    } finally {
      setActionLoading(null);
    }
  };

  const handleConnect = async (id: string) => {
    try {
      setActionLoading(id);
      setErrorMsg(null);
      await apiService.connectDevice(id);
      await fetchDevices();
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message || 'Connection failed');
      await fetchDevices();
    } finally {
      setActionLoading(null);
    }
  };

  const handleDisconnect = async (id: string) => {
    try {
      setActionLoading(id);
      setErrorMsg(null);
      await apiService.disconnectDevice(id);
      await fetchDevices();
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message || 'Disconnect failed');
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <CircuitBoard className="text-emerald-500" size={26} />
            Embedded-System Integration & Hardware Adapters
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Task E • Host-connected modular adapters (MCU, FPGA, JTAG) with simulated telemetry & recoverable fault injection
          </p>
        </div>

        <button
          onClick={fetchDevices}
          disabled={loading}
          className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium py-2 px-4 rounded-lg border border-slate-700 transition flex items-center gap-2"
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          Refresh Status
        </button>
      </div>

      {/* Error alert banner */}
      {errorMsg && (
        <div className="p-4 rounded-lg bg-rose-950/70 border border-rose-800 text-rose-300 text-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle size={18} className="shrink-0 text-rose-400" />
            <div>
              <span className="font-semibold block">Hardware Fault Detected:</span>
              <span>{errorMsg}</span>
            </div>
          </div>
          <span className="text-xs text-rose-400 font-mono bg-rose-900/50 px-2 py-1 rounded">
            Recoverable Fault
          </span>
        </div>
      )}

      {/* Three Device Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {devices.map((dev) => {
          const isConnected = dev.status === 'Connected';
          const isError = dev.status === 'Error';
          const isBusy = actionLoading === dev.id;

          return (
            <div
              key={dev.id}
              className={`bg-slate-900 border rounded-xl p-5 flex flex-col justify-between transition ${
                isConnected
                  ? 'border-emerald-600/60 shadow-lg shadow-emerald-950/30'
                  : isError
                  ? 'border-rose-600/60 shadow-lg shadow-rose-950/30'
                  : 'border-slate-800'
              }`}
            >
              <div>
                {/* Device Title & Status */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="text-[10px] font-mono tracking-wider uppercase text-blue-400 bg-blue-950/50 px-2 py-0.5 rounded border border-blue-900/40">
                      {dev.type}
                    </span>
                    <h3 className="text-base font-semibold text-white mt-1.5">{dev.name}</h3>
                  </div>

                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                      isConnected
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60'
                        : isError
                        ? 'bg-rose-950/80 text-rose-300 border-rose-700/60'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isConnected
                          ? 'bg-emerald-400 animate-pulse'
                          : isError
                          ? 'bg-rose-400'
                          : 'bg-slate-500'
                      }`}
                    />
                    {dev.status}
                  </span>
                </div>

                <div className="text-[10px] text-amber-400/90 font-mono bg-amber-950/30 border border-amber-900/30 px-2 py-1 rounded mb-4">
                  [SIMULATED C++ ADAPTER] No real wiring required
                </div>

                {/* Capabilities */}
                {dev.capabilities && (
                  <div className="space-y-2 mb-4 text-xs">
                    <div className="text-slate-400 font-medium text-[11px] uppercase tracking-wider">
                      Specifications:
                    </div>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 space-y-1 font-mono text-[11px] text-slate-300">
                      <div>Firmware: {dev.capabilities.firmware_version}</div>
                      <div>Sample Rate: {(dev.capabilities.max_sample_rate_hz / 1e6).toFixed(1)} MHz</div>
                      <div>Protocols: {dev.capabilities.supported_protocols.join(', ')}</div>
                      <div>GPIO Pins: {dev.capabilities.gpio_pins}</div>
                    </div>
                  </div>
                )}

                {/* Live Telemetry */}
                {dev.telemetry && isConnected && (
                  <div className="space-y-2 mb-4 text-xs">
                    <div className="text-emerald-400 font-medium text-[11px] uppercase tracking-wider flex items-center gap-1.5">
                      <Activity size={13} />
                      Live Host Telemetry:
                    </div>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 space-y-1 font-mono text-[11px] text-slate-300">
                      <div className="flex justify-between">
                        <span>Die Temperature:</span>
                        <span className="text-rose-400">{dev.telemetry.temperature_celsius.toFixed(1)} °C</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Core / Target Rail:</span>
                        <span className="text-emerald-400">{dev.telemetry.voltage_v.toFixed(2)} V</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Current Draw:</span>
                        <span className="text-blue-400">{dev.telemetry.current_ma.toFixed(1)} mA</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Host Uptime:</span>
                        <span>{dev.telemetry.uptime_seconds}s</span>
                      </div>
                      <div className="pt-1 text-[10px] text-slate-400 border-t border-slate-800 mt-1 truncate">
                        {dev.telemetry.status_message}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-3 border-t border-slate-800">
                <button
                  onClick={() => handleDiscover(dev.id)}
                  disabled={isBusy}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-medium py-2 rounded-lg transition flex items-center justify-center gap-1.5 border border-slate-700"
                >
                  <Search size={13} />
                  Discover
                </button>

                {isConnected ? (
                  <button
                    onClick={() => handleDisconnect(dev.id)}
                    disabled={isBusy}
                    className="flex-1 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-medium py-2 rounded-lg transition flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <PowerOff size={13} />
                    Disconnect
                  </button>
                ) : (
                  <button
                    onClick={() => handleConnect(dev.id)}
                    disabled={isBusy}
                    className="flex-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-medium py-2 rounded-lg transition flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Power size={13} />
                    {isError ? 'Retry Connect' : 'Connect'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Block Diagram & Electrical Interface Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Architecture Block Diagram */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
            <Cpu size={16} className="text-blue-400" />
            Hardware Architecture Block Diagram
          </h3>
          <p className="text-xs text-slate-400">
            Modular engineering testbench isolation layer connecting host PC with embedded targets.
          </p>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs font-mono space-y-3 leading-relaxed text-slate-300">
            <div className="p-2.5 rounded bg-blue-950/40 border border-blue-900/60 text-center font-bold text-blue-300">
              Host Workstation (Windows 11 x64 / C++17 REST Core)
            </div>
            <div className="text-center text-slate-500">│  USB 2.0 / USB-C (5V VBUS + High-Speed Differential)</div>
            <div className="p-2.5 rounded bg-slate-900 border border-slate-700 text-center font-semibold text-slate-200">
              Device Interface & Hardware Abstraction Layer (IDeviceAdapter)
            </div>
            <div className="grid grid-cols-3 gap-2 pt-2 text-center text-[11px]">
              <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
                <span className="text-emerald-400 font-semibold block">UART / SPI</span>
                <span className="text-slate-400 text-[10px]">3.3V LVCMOS</span>
                <span className="block mt-1 font-bold text-slate-200">ESP32 DevKit</span>
              </div>
              <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
                <span className="text-cyan-400 font-semibold block">FTDI / PMOD</span>
                <span className="text-slate-400 text-[10px]">1.0V/3.3V Logic</span>
                <span className="block mt-1 font-bold text-slate-200">Artix-7 FPGA</span>
              </div>
              <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
                <span className="text-purple-400 font-semibold block">JTAG TAP / SWD</span>
                <span className="text-slate-400 text-[10px]">VTref Sensing</span>
                <span className="block mt-1 font-bold text-slate-200">J-Link Probe</span>
              </div>
            </div>
          </div>
        </div>

        {/* Pin-Voltage & Isolation Specification Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck size={16} className="text-emerald-400" />
            Interface, Voltage Domain & Safety Table
          </h3>
          <p className="text-xs text-slate-400">
            Why devices cannot arbitrarily share headers: voltage domains & JTAG signal ownership.
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px] font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 px-2">Device</th>
                  <th className="py-2 px-2">Supply</th>
                  <th className="py-2 px-2">Logic V</th>
                  <th className="py-2 px-2">Connector</th>
                  <th className="py-2 px-2">Level Shift?</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 px-2 font-semibold text-slate-100">ESP32 MCU</td>
                  <td className="py-2 px-2">5V USB / 3.3V</td>
                  <td className="py-2 px-2 text-cyan-400">3.3V LVCMOS</td>
                  <td className="py-2 px-2">Micro-USB / 2.54mm</td>
                  <td className="py-2 px-2 text-amber-400">Required if 5V</td>
                </tr>
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 px-2 font-semibold text-slate-100">Artix-7 FPGA</td>
                  <td className="py-2 px-2">5V Ext / USB</td>
                  <td className="py-2 px-2 text-rose-400">1.0V core, 3.3V I/O</td>
                  <td className="py-2 px-2">USB-B / PMOD</td>
                  <td className="py-2 px-2 text-rose-400">Crucial (no 5V tol)</td>
                </tr>
                <tr className="hover:bg-slate-800/40">
                  <td className="py-2 px-2 font-semibold text-slate-100">JTAG Probe</td>
                  <td className="py-2 px-2">5V USB</td>
                  <td className="py-2 px-2 text-purple-400">1.2V – 5.0V (VTref)</td>
                  <td className="py-2 px-2">20-pin 0.1" Ribbon</td>
                  <td className="py-2 px-2 text-emerald-400">Built-in buffer</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[11px] text-slate-400 leading-relaxed space-y-1">
            <span className="font-semibold text-slate-300 block">Engineering Integration Note:</span>
            JTAG is a hardware debugging interface with master signal ownership (driving TCK/TMS/TDI into target TAPs). Unlike peripheral buses (I2C/SPI), JTAG cannot be shared with arbitrary compute peripherals and requires dedicated common grounding and VTref reference tracking.
          </div>
        </div>
      </div>
    </div>
  );
};
