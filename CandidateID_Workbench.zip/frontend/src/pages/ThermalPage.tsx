import React, { useState } from 'react';
import { apiService } from '../services/api';
import type { ThermalResult, ConvergenceResult, ThermalParams } from '../types';
import { 
  Flame, 
  Play, 
  TrendingDown, 
  Download, 
  AlertTriangle, 
  CheckCircle2, 
  Settings2,
  Table as TableIcon
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export const ThermalPage: React.FC = () => {
  const [params, setParams] = useState<ThermalParams>({
    L: 1.0,
    A: 1e-4,
    k: 10.0,
    q: 10000.0,
    T_left: 100.0,
    T_right: 20.0,
    num_elements: 20,
  });

  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ThermalResult | null>(null);
  const [convergence, setConvergence] = useState<ConvergenceResult | null>(null);

  const handleSolve = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await apiService.solveThermal(params);
      setResult(res);

      // Also automatically update convergence study
      const convRes = await apiService.runConvergenceStudy(params);
      setConvergence(convRes);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Thermal solve failed');
    } finally {
      setLoading(false);
    }
  };

  const handleParamChange = (field: keyof ThermalParams, value: number) => {
    setParams((prev) => ({ ...prev, [field]: value }));
  };

  const exportCsv = () => {
    if (!result) return;
    let csv = 'position_m,fe_temperature_C,exact_temperature_C,error_C\n';
    result.nodes.forEach((n) => {
      csv += `${n.position.toFixed(6)},${n.temperature.toFixed(6)},${n.exact_temperature.toFixed(6)},${Math.abs(n.temperature - n.exact_temperature).toExponential(6)}\n`;
    });

    csv += '\n# Element Midpoints Analysis\nmidpoint_position_m,midpoint_fe_temp_C,midpoint_exact_temp_C,midpoint_error_C\n';
    result.midpoints.forEach((m) => {
      csv += `${m.position.toFixed(6)},${m.fe_temp.toFixed(6)},${m.exact_temp.toFixed(6)},${m.error.toExponential(6)}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `thermal_fea_N${result.num_elements}_results.csv`;
    a.click();
  };

  // Prepare chart data
  const chartData = result?.nodes.map((n) => ({
    x: parseFloat(n.position.toFixed(3)),
    'FEA Solution': parseFloat(n.temperature.toFixed(4)),
    'Exact Analytical': parseFloat(n.exact_temperature.toFixed(4)),
  })) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Flame className="text-rose-500" size={26} />
            1D Steady-State Thermal Finite-Element Solver
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Task C • Numerical rod conduction with internal heat generation & midpoint error verification
          </p>
        </div>

        <div className="flex items-center gap-3">
          {result && (
            <button
              onClick={exportCsv}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium py-2 px-4 rounded-lg border border-slate-700 transition flex items-center gap-2"
            >
              <Download size={15} />
              Export CSV
            </button>
          )}
          <button
            onClick={handleSolve}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-medium py-2 px-5 rounded-lg shadow-md shadow-blue-600/30 transition flex items-center gap-2"
          >
            <Play size={15} className={loading ? 'animate-spin' : ''} />
            {loading ? 'Solving...' : 'Run FEA Solver'}
          </button>
        </div>
      </div>

      {/* Error alert */}
      {error && (
        <div className="p-4 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-sm flex items-center gap-3">
          <AlertTriangle size={18} className="shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Controls & Parameters Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Parameters Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
            <Settings2 size={16} className="text-blue-400" />
            Physical Parameters
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Rod Length L [m]</label>
              <input
                type="number"
                step="0.1"
                value={params.L}
                onChange={(e) => handleParamChange('L', parseFloat(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Cross-section A [m²]</label>
              <input
                type="number"
                step="0.00001"
                value={params.A}
                onChange={(e) => handleParamChange('A', parseFloat(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Conductivity k [W/(m·K)]</label>
              <input
                type="number"
                step="1"
                value={params.k}
                onChange={(e) => handleParamChange('k', parseFloat(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Heat Generation q [W/m³]</label>
              <input
                type="number"
                step="100"
                value={params.q}
                onChange={(e) => handleParamChange('q', parseFloat(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-1">T(0) [°C]</label>
                <input
                  type="number"
                  value={params.T_left}
                  onChange={(e) => handleParamChange('T_left', parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">T(L) [°C]</label>
                <input
                  type="number"
                  value={params.T_right}
                  onChange={(e) => handleParamChange('T_right', parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Mesh Elements N</label>
              <select
                value={params.num_elements}
                onChange={(e) => handleParamChange('num_elements', parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              >
                <option value={10}>N = 10 elements</option>
                <option value={20}>N = 20 elements</option>
                <option value={40}>N = 40 elements</option>
                <option value={80}>N = 80 elements</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results Graph Column */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                Temperature Distribution along Rod (L = 1m)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                FEA Solution vs Analytical: T_exact(x) = 100 - 80x + 500x(1-x)
              </p>
            </div>
            {result && (
              <span className="flex items-center gap-1.5 text-emerald-400 text-xs font-mono font-medium bg-emerald-950/60 border border-emerald-800/60 px-3 py-1 rounded-full">
                <CheckCircle2 size={13} />
                Max Midpoint Error: {result.max_midpoint_error.toExponential(4)} °C
              </span>
            )}
          </div>

          <div className="h-72 w-full">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis 
                    dataKey="x" 
                    stroke="#64748b" 
                    fontSize={11} 
                    label={{ value: 'Position x [m]', position: 'insideBottom', offset: -10, fill: '#94a3b8' }} 
                  />
                  <YAxis 
                    stroke="#64748b" 
                    fontSize={11} 
                    label={{ value: 'Temperature [°C]', angle: -90, position: 'insideLeft', fill: '#94a3b8' }} 
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} 
                  />
                  <Legend verticalAlign="top" height={36} />
                  <Line 
                    type="monotone" 
                    dataKey="FEA Solution" 
                    stroke="#3b82f6" 
                    strokeWidth={2} 
                    dot={{ r: 3, fill: '#3b82f6' }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Exact Analytical" 
                    stroke="#f43f5e" 
                    strokeWidth={2} 
                    strokeDasharray="5 5" 
                    dot={false} 
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                Click "Run FEA Solver" to compute temperature field.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mesh Convergence & Error Table */}
      {convergence && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Convergence Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
              <TableIcon size={16} className="text-blue-400" />
              Mesh Convergence Error Table (N = 10, 20, 40, 80)
            </h3>
            <p className="text-xs text-slate-400">
              Evaluated at <strong>element midpoints</strong> using linear FE shape function interpolation.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3">Elements (N)</th>
                    <th className="py-2.5 px-3">Element Size Le [m]</th>
                    <th className="py-2.5 px-3">Max Midpoint Error [°C]</th>
                    <th className="py-2.5 px-3">Theoretical O(h²) Ratio</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {convergence.convergence.map((pt, idx, arr) => {
                    const prev = arr[idx - 1];
                    const ratio = prev ? (prev.max_midpoint_error / pt.max_midpoint_error).toFixed(2) : '-';
                    return (
                      <tr key={pt.num_elements} className="hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 text-slate-200 font-semibold">{pt.num_elements}</td>
                        <td className="py-2.5 px-3 text-slate-400">{pt.element_size.toFixed(4)}</td>
                        <td className="py-2.5 px-3 text-rose-400 font-medium">
                          {pt.max_midpoint_error.toExponential(5)}
                        </td>
                        <td className="py-2.5 px-3 text-emerald-400">{ratio}x</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Convergence Plot */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                <TrendingDown size={16} className="text-emerald-400" />
                Mesh Convergence Plot (Error vs Mesh Size)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Demonstrates quadratic O(h²) error decay expected for 2-node linear elements.
              </p>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart 
                  data={convergence.convergence.map((c) => ({
                    elements: `N=${c.num_elements}`,
                    error: parseFloat(c.max_midpoint_error.toExponential(4)),
                  }))}
                  margin={{ top: 10, right: 30, left: 10, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="elements" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="error" 
                    name="Max Midpoint Error (°C)" 
                    stroke="#10b981" 
                    strokeWidth={2} 
                    dot={{ r: 4, fill: '#10b981' }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
