import React, { useState, useRef, useEffect } from 'react';
import { apiService } from '../services/api';
import type { StlData, TemperatureData, TemperatureNode } from '../types';
import { Upload, Box, Flame, RefreshCw, ZoomIn, Info, AlertTriangle } from 'lucide-react';
import * as THREE from 'three';

export const GeometryPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'stl' | 'csv'>('stl');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // STL State
  const [stlData, setStlData] = useState<StlData | null>(null);
  const stlMountRef = useRef<HTMLDivElement>(null);
  const stlSceneRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    mesh?: THREE.Mesh;
  } | null>(null);

  // CSV Temperature State
  const [tempData, setTempData] = useState<TemperatureData | null>(null);
  const [selectedNode, setSelectedNode] = useState<TemperatureNode | null>(null);
  const csvMountRef = useRef<HTMLDivElement>(null);
  const csvSceneRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    points?: THREE.Points;
  } | null>(null);

  // Load sample data helper
  const loadSampleStl = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/data/sample_cube.stl');
      const text = await res.text();
      const parsed = await apiService.parseStl(text);
      setStlData(parsed);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Failed to parse STL');
    } finally {
      setLoading(false);
    }
  };

  const loadSampleCsv = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/data/sample_temperature.csv');
      const text = await res.text();
      const parsed = await apiService.parseTemperatureCsv(text);
      setTempData(parsed);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Failed to parse Temperature CSV');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'stl' | 'csv') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const text = evt.target?.result as string;
      try {
        if (type === 'stl') {
          const parsed = await apiService.parseStl(text);
          setStlData(parsed);
        } else {
          const parsed = await apiService.parseTemperatureCsv(text);
          setTempData(parsed);
        }
      } catch (err: any) {
        setError(err.response?.data?.error || err.message || 'Parsing failed');
      } finally {
        setLoading(false);
      }
    };
    reader.readAsText(file);
  };

  // Render STL 3D Mesh
  useEffect(() => {
    if (activeTab !== 'stl' || !stlMountRef.current) return;

    const width = stlMountRef.current.clientWidth || 600;
    const height = 480;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a); // slate-900

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(2.5, 2.5, 3.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);

    stlMountRef.current.innerHTML = '';
    stlMountRef.current.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight1.position.set(5, 10, 7);
    scene.add(dirLight1);
    const dirLight2 = new THREE.DirectionalLight(0x60a5fa, 0.4);
    dirLight2.position.set(-5, -5, -5);
    scene.add(dirLight2);

    // Grid
    const grid = new THREE.GridHelper(10, 20, 0x334155, 0x1e293b);
    grid.position.y = -0.5;
    scene.add(grid);

    stlSceneRef.current = { scene, camera, renderer };

    // Mouse interaction (Rotate / Pan)
    let isDragging = false;
    let prevMouse = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouse.x;
      const deltaY = e.clientY - prevMouse.y;
      prevMouse = { x: e.clientX, y: e.clientY };

      const mesh = stlSceneRef.current?.mesh;
      if (mesh) {
        mesh.rotation.y += deltaX * 0.01;
        mesh.rotation.x += deltaY * 0.01;
      }
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z += e.deltaY * 0.005;
      camera.position.z = Math.max(1, Math.min(20, camera.position.z));
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel);

    let reqId: number;
    const animate = () => {
      reqId = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(reqId);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      renderer.dispose();
    };
  }, [activeTab]);

  // Update STL geometry when stlData changes
  useEffect(() => {
    if (!stlSceneRef.current || !stlData) return;
    const { scene, camera } = stlSceneRef.current;

    if (stlSceneRef.current.mesh) {
      scene.remove(stlSceneRef.current.mesh);
    }

    const positions: number[] = [];
    const normals: number[] = [];

    stlData.triangles.forEach((tri) => {
      tri.vertices.forEach((v) => {
        positions.push(v[0], v[1], v[2]);
        normals.push(tri.normal[0], tri.normal[1], tri.normal[2]);
      });
    });

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    geometry.computeBoundingBox();

    // Center geometry
    geometry.center();

    const material = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      metalness: 0.2,
      roughness: 0.4,
      side: THREE.DoubleSide,
      wireframe: false,
    });

    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);
    stlSceneRef.current.mesh = mesh;

    // Fit to view
    camera.position.set(2, 2, 3);
    camera.lookAt(0, 0, 0);
  }, [stlData]);

  // Render CSV Point Cloud
  useEffect(() => {
    if (activeTab !== 'csv' || !csvMountRef.current) return;

    const width = csvMountRef.current.clientWidth || 600;
    const height = 480;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(1.5, 1.5, 2.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);

    csvMountRef.current.innerHTML = '';
    csvMountRef.current.appendChild(renderer.domElement);

    const grid = new THREE.GridHelper(5, 10, 0x334155, 0x1e293b);
    grid.position.y = -0.1;
    scene.add(grid);

    csvSceneRef.current = { scene, camera, renderer };

    let isDragging = false;
    let prevMouse = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouse.x;
      const deltaY = e.clientY - prevMouse.y;
      prevMouse = { x: e.clientX, y: e.clientY };

      const points = csvSceneRef.current?.points;
      if (points) {
        points.rotation.y += deltaX * 0.01;
        points.rotation.x += deltaY * 0.01;
      }
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z += e.deltaY * 0.005;
      camera.position.z = Math.max(0.5, Math.min(15, camera.position.z));
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel);

    let reqId: number;
    const animate = () => {
      reqId = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(reqId);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      renderer.dispose();
    };
  }, [activeTab]);

  // Update CSV Point Cloud when tempData changes
  useEffect(() => {
    if (!csvSceneRef.current || !tempData || tempData.nodes.length === 0) return;
    const { scene } = csvSceneRef.current;

    if (csvSceneRef.current.points) {
      scene.remove(csvSceneRef.current.points);
    }

    const positions: number[] = [];
    const colors: number[] = [];

    const minT = tempData.min_temperature;
    const maxT = tempData.max_temperature;
    const range = maxT - minT || 1.0;

    tempData.nodes.forEach((n) => {
      positions.push(n.x, n.y, n.z);

      // Color mapping: Blue (cold) to Red (hot)
      const norm = (n.temperature - minT) / range;
      const color = new THREE.Color();
      // HSL: 0.66 (blue) -> 0.0 (red)
      color.setHSL(0.66 * (1.0 - norm), 1.0, 0.5);
      colors.push(color.r, color.g, color.b);
    });

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geometry.center();

    const material = new THREE.PointsMaterial({
      size: 0.06,
      vertexColors: true,
    });

    const points = new THREE.Points(geometry, material);
    scene.add(points);
    csvSceneRef.current.points = points;
  }, [tempData]);

  const resetStlView = () => {
    if (stlSceneRef.current?.mesh) {
      stlSceneRef.current.mesh.rotation.set(0, 0, 0);
      stlSceneRef.current.camera.position.set(2, 2, 3);
      stlSceneRef.current.camera.lookAt(0, 0, 0);
    }
  };

  const resetCsvView = () => {
    if (csvSceneRef.current?.points) {
      csvSceneRef.current.points.rotation.set(0, 0, 0);
      csvSceneRef.current.camera.position.set(1.5, 1.5, 2.5);
      csvSceneRef.current.camera.lookAt(0, 0, 0);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Box className="text-blue-500" size={26} />
            Geometry & Temperature Visualization
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Task B • ASCII STL CAD Import & ANSYS-Style CSV 3D Point-Cloud Temperature Mapping
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('stl')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'stl'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Box size={16} />
            ASCII STL Viewer
          </button>
          <button
            onClick={() => setActiveTab('csv')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'csv'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Flame size={16} />
            ANSYS-Style CSV Viewer
          </button>
        </div>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="p-4 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-sm flex items-center gap-3">
          <AlertTriangle size={18} className="shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* STL Tab View */}
      {activeTab === 'stl' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controls & Metrics */}
          <div className="space-y-6">
            {/* File Upload Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                <Upload size={16} className="text-blue-400" />
                Import Geometry File
              </h3>
              <p className="text-xs text-slate-400">
                Upload a standard ASCII STL file. Triangles will be parsed in C++17 and rendered with Three.js.
              </p>

              <div className="flex gap-2">
                <label className="flex-1 cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium py-2.5 px-3 rounded-lg border border-slate-700 text-center transition">
                  <span>Browse .stl</span>
                  <input
                    type="file"
                    accept=".stl"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'stl')}
                  />
                </label>
                <button
                  onClick={loadSampleStl}
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-medium py-2.5 px-4 rounded-lg transition flex items-center gap-1.5"
                >
                  <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
                  Load Sample
                </button>
              </div>
            </div>

            {/* Geometry Stats Card */}
            {stlData ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                  <Info size={16} className="text-emerald-400" />
                  Mesh Metadata (C++ Verified)
                </h3>
                <dl className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Solid Name</dt>
                    <dd className="text-slate-100 font-mono font-medium mt-1">
                      {stlData.solid_name || 'Unnamed'}
                    </dd>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Triangles</dt>
                    <dd className="text-slate-100 font-mono font-medium mt-1">
                      {stlData.triangle_count.toLocaleString()}
                    </dd>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">File Size</dt>
                    <dd className="text-slate-100 font-mono font-medium mt-1">
                      {(stlData.file_size / 1024).toFixed(2)} KB
                    </dd>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Format</dt>
                    <dd className="text-emerald-400 font-mono font-medium mt-1">ASCII STL</dd>
                  </div>
                </dl>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] font-mono space-y-1">
                  <div className="text-slate-400 font-sans font-medium text-xs mb-1">
                    Bounding Box [min / max]:
                  </div>
                  <div className="text-slate-300">
                    X: [{stlData.bounding_box.min[0].toFixed(3)}, {stlData.bounding_box.max[0].toFixed(3)}] m
                  </div>
                  <div className="text-slate-300">
                    Y: [{stlData.bounding_box.min[1].toFixed(3)}, {stlData.bounding_box.max[1].toFixed(3)}] m
                  </div>
                  <div className="text-slate-300">
                    Z: [{stlData.bounding_box.min[2].toFixed(3)}, {stlData.bounding_box.max[2].toFixed(3)}] m
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-900/50 border border-dashed border-slate-800 rounded-xl p-8 text-center text-xs text-slate-400">
                No STL file loaded yet. Click <strong>Load Sample</strong> or upload your own ASCII STL file.
              </div>
            )}
          </div>

          {/* 3D Viewport */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
            <div className="h-10 bg-slate-950/70 border-b border-slate-800 px-4 flex items-center justify-between text-xs text-slate-400">
              <span>Three.js WebGL Viewport (Left-click to Rotate • Scroll to Zoom)</span>
              <button
                onClick={resetStlView}
                className="hover:text-white flex items-center gap-1 transition"
              >
                <ZoomIn size={13} />
                Fit to View
              </button>
            </div>
            <div ref={stlMountRef} className="h-[480px] w-full cursor-grab active:cursor-grabbing" />
          </div>
        </div>
      )}

      {/* CSV Tab View */}
      {activeTab === 'csv' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controls & Metrics */}
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                <Upload size={16} className="text-blue-400" />
                Import Temperature CSV
              </h3>
              <p className="text-xs text-slate-400">
                Format: <code className="text-blue-400">node_id,x_m,y_m,z_m,temperature_C</code>.
                Parsed in C++ with NaN/Inf numerical checks.
              </p>

              <div className="flex gap-2">
                <label className="flex-1 cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium py-2.5 px-3 rounded-lg border border-slate-700 text-center transition">
                  <span>Browse .csv</span>
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'csv')}
                  />
                </label>
                <button
                  onClick={loadSampleCsv}
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-medium py-2.5 px-4 rounded-lg transition flex items-center gap-1.5"
                >
                  <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
                  Load Sample
                </button>
              </div>
            </div>

            {tempData && (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                  <Info size={16} className="text-emerald-400" />
                  Thermal Field Statistics
                </h3>
                <dl className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Node Count</dt>
                    <dd className="text-slate-100 font-mono font-medium mt-1">
                      {tempData.node_count.toLocaleString()}
                    </dd>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Provenance</dt>
                    <dd className="text-amber-400 font-mono font-medium mt-1">SYNTHETIC</dd>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Min Temp</dt>
                    <dd className="text-cyan-400 font-mono font-medium mt-1">
                      {tempData.min_temperature.toFixed(2)} °C
                    </dd>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <dt className="text-slate-400">Max Temp</dt>
                    <dd className="text-rose-400 font-mono font-medium mt-1">
                      {tempData.max_temperature.toFixed(2)} °C
                    </dd>
                  </div>
                </dl>

                {/* Temperature Gradient Legend */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between text-[11px] text-slate-400 font-medium">
                    <span className="text-cyan-400">{tempData.min_temperature.toFixed(1)} °C</span>
                    <span>Temperature Scale (°C)</span>
                    <span className="text-rose-400">{tempData.max_temperature.toFixed(1)} °C</span>
                  </div>
                  <div className="h-3 w-full rounded bg-gradient-to-r from-blue-600 via-emerald-400 via-amber-400 to-rose-600 border border-slate-700" />
                </div>

                {/* Node Inspection Panel */}
                <div className="pt-2 border-t border-slate-800">
                  <h4 className="text-xs font-semibold text-slate-300 mb-2">Inspect First 5 Nodes:</h4>
                  <div className="max-h-40 overflow-y-auto space-y-1 font-mono text-[11px]">
                    {tempData.nodes.slice(0, 5).map((node) => (
                      <div
                        key={node.node_id}
                        onClick={() => setSelectedNode(node)}
                        className={`p-2 rounded cursor-pointer transition flex justify-between items-center ${
                          selectedNode?.node_id === node.node_id
                            ? 'bg-blue-600/30 border border-blue-500 text-white'
                            : 'bg-slate-950 hover:bg-slate-800/80 text-slate-300 border border-slate-800/60'
                        }`}
                      >
                        <span>Node #{node.node_id}</span>
                        <span>({node.x.toFixed(1)}, {node.y.toFixed(1)}, {node.z.toFixed(1)}) m</span>
                        <span className="text-rose-400 font-medium">{node.temperature.toFixed(1)} °C</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 3D Viewport */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
            <div className="h-10 bg-slate-950/70 border-b border-slate-800 px-4 flex items-center justify-between text-xs text-slate-400">
              <span>Coloured 3D Point-Cloud Viewport</span>
              <button
                onClick={resetCsvView}
                className="hover:text-white flex items-center gap-1 transition"
              >
                <ZoomIn size={13} />
                Fit to View
              </button>
            </div>
            <div ref={csvMountRef} className="h-[480px] w-full cursor-grab active:cursor-grabbing" />
          </div>
        </div>
      )}
    </div>
  );
};
