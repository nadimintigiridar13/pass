#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>
#include <string>

#include "common/types.h"
#include "common/validation.h"
#include "geometry/stl_parser.h"
#include "geometry/csv_temperature_parser.h"
#include "thermal/thermal_solver.h"
#include "performance/batch_generator.h"
#include "performance/benchmark.h"
#include "hardware/microcontroller_adapter.h"
#include "hardware/fpga_adapter.h"
#include "hardware/jtag_adapter.h"
#include "backpropagation/neural_network.h"

using namespace workbench;

int g_pass_count = 0;
int g_fail_count = 0;

#define TEST_ASSERT(cond, msg) \
    do { \
        if (cond) { \
            std::cout << "  [PASS] " << msg << "\n"; \
            g_pass_count++; \
        } else { \
            std::cerr << "  [FAIL] " << msg << " (" << __FILE__ << ":" << __LINE__ << ")\n"; \
            g_fail_count++; \
        } \
    } while(0)

void test_stl_parser() {
    std::cout << "\n=== 1. Testing Task B: ASCII STL Parser ===\n";
    std::string valid_stl = 
        "solid test_triangle\n"
        "  facet normal 0 0 1\n"
        "    outer loop\n"
        "      vertex 0 0 0\n"
        "      vertex 1 0 0\n"
        "      vertex 0 1 0\n"
        "    endloop\n"
        "  endfacet\n"
        "endsolid test_triangle\n";

    auto res = geometry::parse_stl(valid_stl);
    TEST_ASSERT(res.ok(), "Valid ASCII STL parses successfully");
    TEST_ASSERT(res.value().triangle_count == 1, "Correct triangle count extracted (1)");
    TEST_ASSERT(res.value().solid_name == "test_triangle", "Correct solid name parsed");

    auto empty_res = geometry::parse_stl("");
    TEST_ASSERT(!empty_res.ok(), "Empty STL string correctly rejected");

    std::string malformed = "solid foo\nfacet without normal\nendsolid foo";
    auto bad_res = geometry::parse_stl(malformed);
    TEST_ASSERT(!bad_res.ok(), "Malformed STL format rejected");
}

void test_temperature_csv_parser() {
    std::cout << "\n=== 2. Testing Task B: ANSYS CSV Parser ===\n";
    std::string valid_csv = 
        "node_id,x_m,y_m,z_m,temperature_C\n"
        "1,0.0,0.0,0.0,100.0\n"
        "2,0.5,0.0,0.0,75.0\n"
        "3,1.0,0.0,0.0,20.0\n";

    auto res = geometry::parse_temperature_csv(valid_csv);
    TEST_ASSERT(res.ok(), "Valid ANSYS CSV parses successfully");
    TEST_ASSERT(res.value().nodes.size() == 3, "Parsed 3 temperature nodes");
    TEST_ASSERT(res.value().min_temperature == 20.0, "Correct min temperature (20°C)");
    TEST_ASSERT(res.value().max_temperature == 100.0, "Correct max temperature (100°C)");

    std::string bad_header = "id,x,y,z,temp\n1,0,0,0,100\n";
    auto bad_res = geometry::parse_temperature_csv(bad_header);
    TEST_ASSERT(!bad_res.ok(), "CSV with invalid headers rejected");

    std::string nan_csv = "node_id,x_m,y_m,z_m,temperature_C\n1,0.0,0.0,0.0,NaN\n";
    auto nan_res = geometry::parse_temperature_csv(nan_csv);
    TEST_ASSERT(!nan_res.ok(), "CSV containing NaN rejected");
}

void test_thermal_fea_solver() {
    std::cout << "\n=== 3. Testing Task C: 1D Thermal FEA Solver ===\n";
    ThermalParams p;
    p.L = 1.0;
    p.A = 1e-4;
    p.k = 10.0;
    p.q = 10000.0;
    p.T_left = 100.0;
    p.T_right = 20.0;

    int meshes[] = {10, 20, 40, 80};
    double prev_error = 1e9;

    for (int n : meshes) {
        p.num_elements = n;
        auto res = thermal::solve(p);
        TEST_ASSERT(res.ok(), "Thermal solve converged for N = " + std::to_string(n));
        if (res.ok()) {
            double err = res.value().max_error;
            TEST_ASSERT(err < prev_error, "Error decays monotonically as mesh is refined (" + std::to_string(err) + " < " + std::to_string(prev_error) + ")");
            prev_error = err;
        }
    }
}

void test_multicore_benchmark() {
    std::cout << "\n=== 4. Testing Task D: Multicore Execution & Thread Pool ===\n";
    auto res = performance::run_benchmark(30, 20, 2);
    TEST_ASSERT(res.ok(), "Multithreaded batch benchmark executed");
    if (res.ok()) {
        const auto& b = res.value();
        TEST_ASSERT(b.results_agree, "Serial vs Parallel results agree within 1e-8 °C");
        TEST_ASSERT(b.max_disagreement <= 1e-8, "Maximum numerical disagreement <= 1e-8 °C");
    }
}

void test_hardware_adapters() {
    std::cout << "\n=== 5. Testing Task E: Embedded Hardware Adapters ===\n";
    hardware::MicrocontrollerAdapter mcu;
    hardware::FPGABoardAdapter fpga;
    hardware::JTAGAdapter jtag;

    // Discovery
    auto disc_mcu = mcu.discover();
    TEST_ASSERT(disc_mcu.ok(), "ESP32 MCU discovered");
    auto disc_fpga = fpga.discover();
    TEST_ASSERT(disc_fpga.ok(), "Artix-7 FPGA discovered");
    auto disc_jtag = jtag.discover();
    TEST_ASSERT(disc_jtag.ok(), "JTAG Probe discovered");

    // Capabilities
    auto caps = mcu.getCapabilities();
    TEST_ASSERT(caps.ok() && caps.value().gpio_pins == 36, "ESP32 capabilities reported correctly");

    // Connect & Telemetry
    auto conn = mcu.connect();
    TEST_ASSERT(conn.ok() || mcu.getStatus() == DeviceStatus::Error, "Connection attempt handled safely");
    if (mcu.getStatus() == DeviceStatus::Connected) {
        auto telem = mcu.getTelemetry();
        TEST_ASSERT(telem.ok() && telem.value().temperature_celsius > 0, "Valid telemetry retrieved");
    }
}

void test_backpropagation() {
    std::cout << "\n=== 6. Testing Task F: Handwritten Backpropagation ===\n";
    NeuralNetParams p;
    p.w = 0.5; p.b = 0.0; p.v = 1.0; p.c = 0.0; p.x = 1.0; p.y = 2.0; p.alpha = 0.1;

    // 1. Forward pass check
    auto fwd = backpropagation::forward(p);
    double expected_h = std::tanh(0.5);
    TEST_ASSERT(std::abs(fwd.h - expected_h) < 1e-6, "Hidden layer activation h = tanh(0.5)");
    TEST_ASSERT(fwd.loss > 0, "Initial loss computed (J > 0)");

    // 2. Central finite-difference verification
    auto ver = backpropagation::verify_gradients(p, 1e-6);
    TEST_ASSERT(ver.passed, "All gradients pass central difference check with error <= 1e-5");
    TEST_ASSERT(ver.max_error <= 1e-5, "Max gradient verification error <= 1e-5 (Actual: " + std::to_string(ver.max_error) + ")");

    // 3. 100-step training check
    auto train = backpropagation::train(p, 100);
    TEST_ASSERT(train.history.size() == 101, "Recorded 100 training steps history");
    TEST_ASSERT(train.final_loss < fwd.loss, "Training monotonically minimizes quadratic loss");
    TEST_ASSERT(train.final_loss < 0.01, "Final loss converges to near zero (< 0.01)");
}

int main() {
    std::cout << "=========================================================\n";
    std::cout << " UNIFIED ENGINEERING WORKBENCH - C++ VERIFICATION SUITE  \n";
    std::cout << "=========================================================\n";

    test_stl_parser();
    test_temperature_csv_parser();
    test_thermal_fea_solver();
    test_multicore_benchmark();
    test_hardware_adapters();
    test_backpropagation();

    std::cout << "\n---------------------------------------------------------\n";
    std::cout << " TEST RESULTS: " << g_pass_count << " PASSED, " << g_fail_count << " FAILED\n";
    std::cout << "---------------------------------------------------------\n";

    return g_fail_count == 0 ? 0 : 1;
}
