#include "common/csv_utils.h"
#include <sstream>
#include <fstream>
#include <algorithm>
#include <cctype>

namespace workbench {
namespace csv {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && std::isspace(static_cast<unsigned char>(s[start]))) ++start;
    size_t end = s.size();
    while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1]))) --end;
    return s.substr(start, end - start);
}

std::vector<std::string> split_line(const std::string& line, char delimiter) {
    std::vector<std::string> fields;
    std::string field;
    bool in_quotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        char ch = line[i];
        if (ch == '"') {
            in_quotes = !in_quotes;
        } else if (ch == delimiter && !in_quotes) {
            fields.push_back(trim(field));
            field.clear();
        } else {
            field += ch;
        }
    }
    fields.push_back(trim(field));
    return fields;
}

int CSVData::column_index(const std::string& name) const {
    for (size_t i = 0; i < headers.size(); ++i) {
        if (headers[i] == name) return static_cast<int>(i);
    }
    return -1;
}

Result<CSVData> parse_csv(const std::string& content) {
    if (content.empty()) {
        return Result<CSVData>::Err(ErrorCode::ParseError, "CSV content is empty");
    }

    std::istringstream stream(content);
    std::string line;
    CSVData data;

    // Read header line
    if (!std::getline(stream, line)) {
        return Result<CSVData>::Err(ErrorCode::ParseError, "CSV has no header line");
    }

    // Remove BOM if present
    if (line.size() >= 3 &&
        static_cast<unsigned char>(line[0]) == 0xEF &&
        static_cast<unsigned char>(line[1]) == 0xBB &&
        static_cast<unsigned char>(line[2]) == 0xBF) {
        line = line.substr(3);
    }

    // Strip trailing \r
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();
    }

    data.headers = split_line(line, ',');

    if (data.headers.empty()) {
        return Result<CSVData>::Err(ErrorCode::ParseError, "CSV header is empty");
    }

    // Read data rows
    int line_num = 1;
    while (std::getline(stream, line)) {
        ++line_num;
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        std::string trimmed = trim(line);
        if (trimmed.empty()) continue; // skip blank lines

        auto fields = split_line(line, ',');

        if (fields.size() != data.headers.size()) {
            return Result<CSVData>::Err(ErrorCode::ParseError,
                "CSV row " + std::to_string(line_num) + " has " +
                std::to_string(fields.size()) + " fields, expected " +
                std::to_string(data.headers.size()));
        }

        CSVRow row;
        row.fields = std::move(fields);
        data.rows.push_back(std::move(row));
    }

    return Result<CSVData>::Ok(std::move(data));
}

Result<CSVData> parse_csv_file(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        return Result<CSVData>::Err(ErrorCode::FileReadError,
            "Cannot open CSV file: " + filepath);
    }
    std::string content((std::istreambuf_iterator<char>(file)),
                         std::istreambuf_iterator<char>());
    return parse_csv(content);
}

std::string write_csv(const CSVData& data) {
    std::ostringstream out;
    for (size_t i = 0; i < data.headers.size(); ++i) {
        if (i > 0) out << ",";
        out << data.headers[i];
    }
    out << "\n";
    for (const auto& row : data.rows) {
        for (size_t i = 0; i < row.fields.size(); ++i) {
            if (i > 0) out << ",";
            out << row.fields[i];
        }
        out << "\n";
    }
    return out.str();
}

} // namespace csv
} // namespace workbench
