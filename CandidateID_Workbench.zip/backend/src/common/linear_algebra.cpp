#include "common/linear_algebra.h"
#include <cmath>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <algorithm>

namespace workbench {
namespace linalg {

// ── Matrix ─────────────────────────────────────────────────────────────────────

Matrix::Matrix() : rows_(0), cols_(0) {}

Matrix::Matrix(size_t rows, size_t cols, double init_val)
    : rows_(rows), cols_(cols), data_(rows * cols, init_val) {}

double& Matrix::operator()(size_t i, size_t j) {
    if (i >= rows_ || j >= cols_)
        throw std::out_of_range("Matrix index out of range: (" +
            std::to_string(i) + "," + std::to_string(j) + ") for " +
            std::to_string(rows_) + "x" + std::to_string(cols_) + " matrix");
    return data_[i * cols_ + j];
}

const double& Matrix::operator()(size_t i, size_t j) const {
    if (i >= rows_ || j >= cols_)
        throw std::out_of_range("Matrix index out of range");
    return data_[i * cols_ + j];
}

void Matrix::add(size_t i, size_t j, double val) {
    if (i >= rows_ || j >= cols_)
        throw std::out_of_range("Matrix::add index out of range");
    data_[i * cols_ + j] += val;
}

void Matrix::apply_bc_row_col(size_t idx) {
    if (idx >= rows_ || idx >= cols_)
        throw std::out_of_range("Matrix::apply_bc_row_col index out of range");
    for (size_t j = 0; j < cols_; ++j) data_[idx * cols_ + j] = 0.0;
    for (size_t i = 0; i < rows_; ++i) data_[i * cols_ + idx] = 0.0;
    data_[idx * cols_ + idx] = 1.0;
}

std::string Matrix::to_string() const {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6);
    for (size_t i = 0; i < rows_; ++i) {
        for (size_t j = 0; j < cols_; ++j) {
            if (j > 0) oss << " ";
            oss << std::setw(12) << data_[i * cols_ + j];
        }
        oss << "\n";
    }
    return oss.str();
}

// ── Vector ─────────────────────────────────────────────────────────────────────

Vector::Vector() {}

Vector::Vector(size_t n, double init_val) : data_(n, init_val) {}

double& Vector::operator()(size_t i) {
    if (i >= data_.size())
        throw std::out_of_range("Vector index out of range: " + std::to_string(i));
    return data_[i];
}

const double& Vector::operator()(size_t i) const {
    if (i >= data_.size())
        throw std::out_of_range("Vector index out of range");
    return data_[i];
}

double& Vector::operator[](size_t i) { return data_[i]; }
const double& Vector::operator[](size_t i) const { return data_[i]; }

void Vector::add(size_t i, double val) {
    if (i >= data_.size())
        throw std::out_of_range("Vector::add index out of range");
    data_[i] += val;
}

std::string Vector::to_string() const {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6);
    oss << "[";
    for (size_t i = 0; i < data_.size(); ++i) {
        if (i > 0) oss << ", ";
        oss << data_[i];
    }
    oss << "]";
    return oss.str();
}

// ── Thomas algorithm for tridiagonal systems ───────────────────────────────────

Result<Vector> solve_tridiagonal(Vector a, Vector b, Vector c, Vector d) {
    // a: sub-diagonal (size n-1), indexed a(0)..a(n-2), a(i) is A[i+1][i]
    // b: diagonal (size n), b(i) is A[i][i]
    // c: super-diagonal (size n-1), c(i) is A[i][i+1]
    // d: right-hand side (size n)

    size_t n = b.size();

    if (n == 0)
        return Result<Vector>::Err(ErrorCode::SolverError, "Empty system");
    if (a.size() != n - 1 || c.size() != n - 1 || d.size() != n)
        return Result<Vector>::Err(ErrorCode::SolverError,
            "Tridiagonal size mismatch: a=" + std::to_string(a.size()) +
            " b=" + std::to_string(b.size()) +
            " c=" + std::to_string(c.size()) +
            " d=" + std::to_string(d.size()));

    // Forward sweep
    std::vector<double> cp(n - 1);
    std::vector<double> dp(n);

    if (std::abs(b(0)) < 1e-30)
        return Result<Vector>::Err(ErrorCode::SolverError, "Zero pivot in Thomas algorithm");

    cp[0] = c(0) / b(0);
    dp[0] = d(0) / b(0);

    for (size_t i = 1; i < n; ++i) {
        double m = a(i - 1);
        double denom = b(i) - m * cp[i - 1];
        if (std::abs(denom) < 1e-30)
            return Result<Vector>::Err(ErrorCode::SolverError,
                "Zero pivot in Thomas algorithm at row " + std::to_string(i));
        if (i < n - 1) {
            cp[i] = c(i) / denom;
        }
        dp[i] = (d(i) - m * dp[i - 1]) / denom;
    }

    // Back substitution
    Vector x(n);
    x(n - 1) = dp[n - 1];
    for (int i = static_cast<int>(n) - 2; i >= 0; --i) {
        x(static_cast<size_t>(i)) = dp[static_cast<size_t>(i)] -
            cp[static_cast<size_t>(i)] * x(static_cast<size_t>(i) + 1);
    }

    return Result<Vector>::Ok(std::move(x));
}

// ── Gaussian elimination with partial pivoting ─────────────────────────────────

Result<Vector> solve_dense(Matrix A, Vector b) {
    size_t n = A.rows();
    if (n == 0)
        return Result<Vector>::Err(ErrorCode::SolverError, "Empty system");
    if (A.cols() != n || b.size() != n)
        return Result<Vector>::Err(ErrorCode::SolverError, "Matrix/vector dimension mismatch");

    // Forward elimination with partial pivoting
    for (size_t k = 0; k < n; ++k) {
        // Find pivot
        size_t max_row = k;
        double max_val = std::abs(A(k, k));
        for (size_t i = k + 1; i < n; ++i) {
            if (std::abs(A(i, k)) > max_val) {
                max_val = std::abs(A(i, k));
                max_row = i;
            }
        }

        if (max_val < 1e-30)
            return Result<Vector>::Err(ErrorCode::SolverError,
                "Singular matrix (zero pivot) at column " + std::to_string(k));

        // Swap rows
        if (max_row != k) {
            for (size_t j = k; j < n; ++j)
                std::swap(A(k, j), A(max_row, j));
            std::swap(b(k), b(max_row));
        }

        // Eliminate
        for (size_t i = k + 1; i < n; ++i) {
            double factor = A(i, k) / A(k, k);
            for (size_t j = k + 1; j < n; ++j) {
                A(i, j) -= factor * A(k, j);
            }
            A(i, k) = 0.0;
            b(i) -= factor * b(k);
        }
    }

    // Back substitution
    Vector x(n);
    for (int i = static_cast<int>(n) - 1; i >= 0; --i) {
        double sum = 0.0;
        for (size_t j = static_cast<size_t>(i) + 1; j < n; ++j) {
            sum += A(static_cast<size_t>(i), j) * x(j);
        }
        x(static_cast<size_t>(i)) = (b(static_cast<size_t>(i)) - sum) /
            A(static_cast<size_t>(i), static_cast<size_t>(i));
    }

    return Result<Vector>::Ok(std::move(x));
}

// ── Vector/Matrix operations ───────────────────────────────────────────────────

Vector matvec(const Matrix& A, const Vector& x) {
    if (A.cols() != x.size())
        throw std::invalid_argument("matvec dimension mismatch");
    Vector result(A.rows());
    for (size_t i = 0; i < A.rows(); ++i) {
        double sum = 0.0;
        for (size_t j = 0; j < A.cols(); ++j) {
            sum += A(i, j) * x(j);
        }
        result(i) = sum;
    }
    return result;
}

double dot(const Vector& a, const Vector& b) {
    if (a.size() != b.size())
        throw std::invalid_argument("dot product dimension mismatch");
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i)
        sum += a(i) * b(i);
    return sum;
}

double norm(const Vector& v) {
    return std::sqrt(dot(v, v));
}

Vector add(const Vector& a, const Vector& b) {
    if (a.size() != b.size())
        throw std::invalid_argument("vector add dimension mismatch");
    Vector result(a.size());
    for (size_t i = 0; i < a.size(); ++i)
        result(i) = a(i) + b(i);
    return result;
}

Vector subtract(const Vector& a, const Vector& b) {
    if (a.size() != b.size())
        throw std::invalid_argument("vector subtract dimension mismatch");
    Vector result(a.size());
    for (size_t i = 0; i < a.size(); ++i)
        result(i) = a(i) - b(i);
    return result;
}

Vector scale(const Vector& v, double s) {
    Vector result(v.size());
    for (size_t i = 0; i < v.size(); ++i)
        result(i) = v(i) * s;
    return result;
}

} // namespace linalg
} // namespace workbench
