#include "common/validation.h"
#include <sstream>
#include <algorithm>
#include <cctype>

namespace workbench {
namespace validation {

bool is_finite(double v) {
    return std::isfinite(v);
}

bool is_positive(double v) {
    return std::isfinite(v) && v > 0.0;
}

bool is_non_negative(double v) {
    return std::isfinite(v) && v >= 0.0;
}

bool is_in_range(double v, double lo, double hi) {
    return std::isfinite(v) && v >= lo && v <= hi;
}

bool is_positive_integer(int v) {
    return v > 0;
}

bool is_non_empty(const std::string& s) {
    return !s.empty();
}

bool file_exists(const std::string& path) {
    return std::filesystem::exists(path);
}

bool has_extension(const std::string& path, const std::string& ext) {
    std::string actual = get_extension(path);
    std::string expected = ext;
    // Case-insensitive comparison
    std::transform(actual.begin(), actual.end(), actual.begin(), ::tolower);
    std::transform(expected.begin(), expected.end(), expected.begin(), ::tolower);
    return actual == expected;
}

std::string get_extension(const std::string& path) {
    auto ext = std::filesystem::path(path).extension().string();
    return ext;
}

std::string validate_thermal_params(double L, double A, double k, double q,
                                     double T_left, double T_right, int num_elements) {
    if (!is_positive(L))
        return "Length L must be positive and finite";
    if (!is_positive(A))
        return "Cross-sectional area A must be positive and finite";
    if (!is_positive(k))
        return "Thermal conductivity k must be positive and finite";
    if (!is_finite(q))
        return "Heat generation q must be finite";
    if (!is_finite(T_left))
        return "Left boundary temperature must be finite";
    if (!is_finite(T_right))
        return "Right boundary temperature must be finite";
    if (!is_positive_integer(num_elements))
        return "Number of elements must be a positive integer";
    if (num_elements > 100000)
        return "Number of elements must be <= 100000";
    return ""; // empty means valid
}

bool try_parse_double(const std::string& s, double& out) {
    if (s.empty()) return false;
    try {
        size_t pos = 0;
        out = std::stod(s, &pos);
        if (pos != s.size()) return false;
        return std::isfinite(out);
    } catch (...) {
        return false;
    }
}

bool try_parse_int(const std::string& s, int& out) {
    if (s.empty()) return false;
    try {
        size_t pos = 0;
        out = std::stoi(s, &pos);
        return pos == s.size();
    } catch (...) {
        return false;
    }
}

} // namespace validation
} // namespace workbench
