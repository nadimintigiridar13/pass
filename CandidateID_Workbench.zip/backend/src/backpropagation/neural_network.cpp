#include "backpropagation/neural_network.h"
#include <cmath>
#include <algorithm>

namespace workbench {
namespace backpropagation {

ForwardResult forward(const NeuralNetParams& p) {
    ForwardResult res;
    res.params = p;
    // Hidden activation: z = w*x + b, h = tanh(z)
    double z = p.w * p.x + p.b;
    res.h = std::tanh(z);
    // Linear output: y_hat = v*h + c
    res.y_hat = p.v * res.h + p.c;
    // Quadratic loss: J = 0.5 * (y_hat - y)^2
    double diff = res.y_hat - p.y;
    res.loss = 0.5 * diff * diff;
    return res;
}

GradientResult compute_gradients(const NeuralNetParams& p) {
    GradientResult res;
    res.forward = forward(p);
    
    double diff = res.forward.y_hat - p.y; // dJ/dy_hat
    double h = res.forward.h;
    
    // Output layer gradients:
    // y_hat = v*h + c
    // dJ/dc = (y_hat - y) * 1
    res.dJ_dc = diff;
    // dJ/dv = (y_hat - y) * h
    res.dJ_dv = diff * h;
    
    // Hidden layer gradients (Backpropagation):
    // dJ/dh = (y_hat - y) * v
    // dh/dz = 1 - tanh^2(z) = 1 - h^2
    // dJ/dz = (y_hat - y) * v * (1 - h^2)
    double dJ_dz = diff * p.v * (1.0 - h * h);
    
    // z = w*x + b
    // dz/dw = x => dJ/dw = dJ/dz * x
    res.dJ_dw = dJ_dz * p.x;
    // dz/db = 1 => dJ/db = dJ/dz * 1
    res.dJ_db = dJ_dz;
    
    return res;
}

// Compute scalar loss for parameter evaluation
static double eval_loss(const NeuralNetParams& p) {
    double z = p.w * p.x + p.b;
    double h = std::tanh(z);
    double y_hat = p.v * h + p.c;
    double diff = y_hat - p.y;
    return 0.5 * diff * diff;
}

GradientVerification verify_gradients(const NeuralNetParams& p, double epsilon) {
    GradientVerification v;
    GradientResult analytical = compute_gradients(p);

    v.dJ_dw_analytical = analytical.dJ_dw;
    v.dJ_db_analytical = analytical.dJ_db;
    v.dJ_dv_analytical = analytical.dJ_dv;
    v.dJ_dc_analytical = analytical.dJ_dc;

    // Central difference for w
    NeuralNetParams pw_plus = p;  pw_plus.w += epsilon;
    NeuralNetParams pw_minus = p; pw_minus.w -= epsilon;
    v.dJ_dw_numerical = (eval_loss(pw_plus) - eval_loss(pw_minus)) / (2.0 * epsilon);
    v.dJ_dw_error = std::abs(v.dJ_dw_analytical - v.dJ_dw_numerical);

    // Central difference for b
    NeuralNetParams pb_plus = p;  pb_plus.b += epsilon;
    NeuralNetParams pb_minus = p; pb_minus.b -= epsilon;
    v.dJ_db_numerical = (eval_loss(pb_plus) - eval_loss(pb_minus)) / (2.0 * epsilon);
    v.dJ_db_error = std::abs(v.dJ_db_analytical - v.dJ_db_numerical);

    // Central difference for v
    NeuralNetParams pv_plus = p;  pv_plus.v += epsilon;
    NeuralNetParams pv_minus = p; pv_minus.v -= epsilon;
    v.dJ_dv_numerical = (eval_loss(pv_plus) - eval_loss(pv_minus)) / (2.0 * epsilon);
    v.dJ_dv_error = std::abs(v.dJ_dv_analytical - v.dJ_dv_numerical);

    // Central difference for c
    NeuralNetParams pc_plus = p;  pc_plus.c += epsilon;
    NeuralNetParams pc_minus = p; pc_minus.c -= epsilon;
    v.dJ_dc_numerical = (eval_loss(pc_plus) - eval_loss(pc_minus)) / (2.0 * epsilon);
    v.dJ_dc_error = std::abs(v.dJ_dc_analytical - v.dJ_dc_numerical);

    v.max_error = std::max({v.dJ_dw_error, v.dJ_db_error, v.dJ_dv_error, v.dJ_dc_error});
    v.passed = (v.max_error <= 1e-5);

    return v;
}

NeuralNetParams step(const NeuralNetParams& p, const GradientResult& grads) {
    NeuralNetParams updated = p;
    updated.w -= p.alpha * grads.dJ_dw;
    updated.b -= p.alpha * grads.dJ_db;
    updated.v -= p.alpha * grads.dJ_dv;
    updated.c -= p.alpha * grads.dJ_dc;
    return updated;
}

TrainingResult train(NeuralNetParams current, int num_steps) {
    TrainingResult result;
    result.initial_verification = verify_gradients(current);

    for (int i = 0; i < num_steps; ++i) {
        GradientResult grads = compute_gradients(current);
        
        TrainingStep s;
        s.step = i;
        s.loss = grads.forward.loss;
        s.y_hat = grads.forward.y_hat;
        s.params = current;
        result.history.push_back(s);

        current = step(current, grads);
    }

    // Add final evaluation after all steps
    ForwardResult final_fwd = forward(current);
    TrainingStep final_step;
    final_step.step = num_steps;
    final_step.loss = final_fwd.loss;
    final_step.y_hat = final_fwd.y_hat;
    final_step.params = current;
    result.history.push_back(final_step);

    result.final_params = current;
    result.final_loss = final_fwd.loss;
    return result;
}

} // namespace backpropagation
} // namespace workbench
