#include "performance/batch_generator.h"
#include <random>

namespace workbench {
namespace performance {

std::vector<ThermalParams> generate_batch(int num_cases, int mesh_size,
                                           unsigned int seed) {
    std::mt19937 rng(seed);
    // k in [1, 100] W/(m·K)
    std::uniform_real_distribution<double> k_dist(1.0, 100.0);
    // q in [100, 50000] W/m³
    std::uniform_real_distribution<double> q_dist(100.0, 50000.0);

    std::vector<ThermalParams> cases;
    cases.reserve(num_cases);

    for (int i = 0; i < num_cases; ++i) {
        ThermalParams p;
        p.L = 1.0;
        p.A = 1e-4;
        p.k = k_dist(rng);
        p.q = q_dist(rng);
        p.T_left = 100.0;
        p.T_right = 20.0;
        p.num_elements = mesh_size;
        cases.push_back(p);
    }

    return cases;
}

} // namespace performance
} // namespace workbench
