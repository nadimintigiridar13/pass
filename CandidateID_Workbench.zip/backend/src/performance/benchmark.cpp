#include "performance/benchmark.h"
#include "performance/batch_generator.h"
#include "thermal/thermal_solver.h"
#include <chrono>
#include <thread>
#include <mutex>
#include <queue>
#include <functional>
#include <algorithm>
#include <sstream>
#include <cmath>
#include <condition_variable>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace workbench {
namespace performance {

std::string get_hardware_info() {
    std::ostringstream oss;
    unsigned int hw_threads = std::thread::hardware_concurrency();
    oss << "Hardware threads: " << hw_threads;

#ifdef _WIN32
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    oss << ", Processor architecture: ";
    switch (si.wProcessorArchitecture) {
        case PROCESSOR_ARCHITECTURE_AMD64: oss << "x64"; break;
        case PROCESSOR_ARCHITECTURE_ARM: oss << "ARM"; break;
        case PROCESSOR_ARCHITECTURE_ARM64: oss << "ARM64"; break;
        case PROCESSOR_ARCHITECTURE_INTEL: oss << "x86"; break;
        default: oss << "Unknown"; break;
    }

    MEMORYSTATUSEX mem;
    mem.dwLength = sizeof(mem);
    if (GlobalMemoryStatusEx(&mem)) {
        oss << ", RAM: " << (mem.ullTotalPhys / (1024 * 1024)) << " MB";
    }
#endif

    return oss.str();
}

namespace {

// Bounded thread pool
class ThreadPool {
public:
    explicit ThreadPool(int num_workers) : stop_(false) {
        for (int i = 0; i < num_workers; ++i) {
            workers_.emplace_back([this]() {
                while (true) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lock(mutex_);
                        cv_.wait(lock, [this]() { return stop_ || !tasks_.empty(); });
                        if (stop_ && tasks_.empty()) return;
                        task = std::move(tasks_.front());
                        tasks_.pop();
                    }
                    task();
                }
            });
        }
    }

    void submit(std::function<void()> task) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            tasks_.push(std::move(task));
        }
        cv_.notify_one();
    }

    void shutdown() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& w : workers_) {
            if (w.joinable()) w.join();
        }
    }

    ~ThreadPool() {
        shutdown();
    }

private:
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex mutex_;
    std::condition_variable cv_;
    bool stop_;
};

// Solve all cases serially, return max temperatures for agreement check
std::vector<double> solve_serial(const std::vector<ThermalParams>& cases) {
    std::vector<double> max_temps(cases.size());
    for (size_t i = 0; i < cases.size(); ++i) {
        auto result = thermal::solve(cases[i]);
        if (result.ok()) {
            max_temps[i] = *std::max_element(
                result.value().temperatures.begin(),
                result.value().temperatures.end());
        } else {
            max_temps[i] = 0.0;
        }
    }
    return max_temps;
}

// Solve all cases in parallel, return max temperatures
std::vector<double> solve_parallel(const std::vector<ThermalParams>& cases, int num_workers) {
    std::vector<double> max_temps(cases.size(), 0.0);
    std::mutex results_mutex;
    std::condition_variable done_cv;
    int completed = 0;

    ThreadPool pool(num_workers);

    for (size_t i = 0; i < cases.size(); ++i) {
        pool.submit([&cases, &max_temps, &results_mutex, &done_cv, &completed, i]() {
            auto result = thermal::solve(cases[i]);
            double max_t = 0.0;
            if (result.ok()) {
                max_t = *std::max_element(
                    result.value().temperatures.begin(),
                    result.value().temperatures.end());
            }
            {
                std::lock_guard<std::mutex> lock(results_mutex);
                max_temps[i] = max_t;
                ++completed;
            }
            done_cv.notify_one();
        });
    }

    // Wait for all tasks to complete
    {
        std::unique_lock<std::mutex> lock(results_mutex);
        done_cv.wait(lock, [&]() { return completed == static_cast<int>(cases.size()); });
    }

    return max_temps;
}

double measure_serial(const std::vector<ThermalParams>& cases) {
    auto start = std::chrono::high_resolution_clock::now();
    solve_serial(cases);
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration<double, std::milli>(end - start).count();
}

double measure_parallel(const std::vector<ThermalParams>& cases, int num_workers) {
    auto start = std::chrono::high_resolution_clock::now();
    solve_parallel(cases, num_workers);
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration<double, std::milli>(end - start).count();
}

double median(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    size_t n = v.size();
    if (n % 2 == 0) return (v[n / 2 - 1] + v[n / 2]) / 2.0;
    return v[n / 2];
}

} // anonymous namespace

Result<BenchmarkTiming> run_benchmark(int num_cases, int mesh_size, int max_workers) {
    if (num_cases <= 0 || num_cases > 10000) {
        return Result<BenchmarkTiming>::Err(ErrorCode::InvalidInput,
            "num_cases must be between 1 and 10000");
    }
    if (mesh_size <= 0 || mesh_size > 10000) {
        return Result<BenchmarkTiming>::Err(ErrorCode::InvalidInput,
            "mesh_size must be between 1 and 10000");
    }
    if (max_workers < 1 || max_workers > 4) {
        return Result<BenchmarkTiming>::Err(ErrorCode::InvalidInput,
            "max_workers must be between 1 and 4");
    }

    auto cases = generate_batch(num_cases, mesh_size);

    // Warm-up run
    solve_serial(cases);

    const int REPS = 5;

    // Serial timing
    std::vector<double> serial_times;
    for (int r = 0; r < REPS; ++r) {
        serial_times.push_back(measure_serial(cases));
    }

    // Parallel timing
    std::vector<double> parallel_times;
    for (int r = 0; r < REPS; ++r) {
        parallel_times.push_back(measure_parallel(cases, max_workers));
    }

    double serial_median = median(serial_times);
    double parallel_median = median(parallel_times);

    // Agreement check
    auto serial_results = solve_serial(cases);
    auto parallel_results = solve_parallel(cases, max_workers);

    double max_disagreement = 0.0;
    for (size_t i = 0; i < cases.size(); ++i) {
        max_disagreement = std::max(max_disagreement,
            std::abs(serial_results[i] - parallel_results[i]));
    }

    BenchmarkTiming timing;
    timing.serial_time_ms = serial_median;
    timing.parallel_time_ms = parallel_median;
    timing.speedup = (parallel_median > 0) ? serial_median / parallel_median : 0.0;
    timing.efficiency = timing.speedup / max_workers;
    timing.num_workers = max_workers;
    timing.num_cases = num_cases;
    timing.mesh_size = mesh_size;
    timing.repetitions = REPS;
    timing.max_disagreement = max_disagreement;
    timing.results_agree = max_disagreement <= 1e-8;
    timing.hardware_info = get_hardware_info();

    return Result<BenchmarkTiming>::Ok(std::move(timing));
}

} // namespace performance
} // namespace workbench
