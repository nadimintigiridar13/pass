#include "hardware/microcontroller_adapter.h"
#include <chrono>
#include <thread>

namespace workbench {
namespace hardware {

MicrocontrollerAdapter::MicrocontrollerAdapter()
    : status_(DeviceStatus::Disconnected),
      discovered_(false),
      connect_attempts_(0),
      rng_(12345) {}

Result<DeviceInfo> MicrocontrollerAdapter::discover() {
    discovered_ = true;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<DeviceCapabilities> MicrocontrollerAdapter::getCapabilities() {
    DeviceCapabilities caps;
    caps.name = "ESP32-WROOM-32D Development Board";
    caps.type = "Microcontroller (Xtensa Dual-Core 240MHz)";
    caps.firmware_version = "v4.4.2-idf";
    caps.supported_protocols = {"UART", "SPI", "I2C", "CAN", "WiFi 802.11b/g/n", "BLE 4.2"};
    caps.max_sample_rate_hz = 2000000;
    caps.adc_resolution_bits = 12;
    caps.gpio_pins = 36;
    return Result<DeviceCapabilities>::Ok(caps);
}

Result<DeviceInfo> MicrocontrollerAdapter::connect() {
    if (!discovered_) {
        return Result<DeviceInfo>::Err(ErrorCode::HardwareError, "Device must be discovered before connecting.");
    }
    
    status_ = DeviceStatus::Connecting;
    connect_attempts_++;

    // Recoverable failure simulation: fail every 3rd attempt to demonstrate error handling
    if (connect_attempts_ % 3 == 0) {
        status_ = DeviceStatus::Error;
        return Result<DeviceInfo>::Err(ErrorCode::HardwareError, 
            "ESP32 UART Connection Timeout: Handshake packet dropped on COM3. Click Connect to retry.");
    }

    status_ = DeviceStatus::Connected;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<DeviceInfo> MicrocontrollerAdapter::disconnect() {
    status_ = DeviceStatus::Disconnected;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<TelemetryData> MicrocontrollerAdapter::getTelemetry() {
    if (status_ != DeviceStatus::Connected) {
        return Result<TelemetryData>::Err(ErrorCode::HardwareError, "ESP32 not connected.");
    }

    std::uniform_real_distribution<double> dist_temp(42.0, 48.5);
    std::uniform_real_distribution<double> dist_cpu(15.0, 65.0);
    std::uniform_real_distribution<double> dist_curr(80.0, 140.0);

    TelemetryData data;
    data.cpu_usage_percent = dist_cpu(rng_);
    data.temperature_celsius = dist_temp(rng_);
    data.voltage_v = 3.31;
    data.current_ma = dist_curr(rng_);
    data.uptime_seconds = 420 + connect_attempts_ * 30;
    data.free_memory_bytes = 184320;
    data.status_message = "FreeRTOS scheduler running; WiFi STA connected (RSSI -58 dBm)";

    return Result<TelemetryData>::Ok(data);
}

DeviceStatus MicrocontrollerAdapter::getStatus() const { return status_; }
std::string MicrocontrollerAdapter::getId() const { return "esp32_mcu"; }
std::string MicrocontrollerAdapter::getName() const { return "ESP32 DevKit-C V4"; }
std::string MicrocontrollerAdapter::getType() const { return "Microcontroller"; }

DeviceInfo MicrocontrollerAdapter::buildInfo() const {
    DeviceInfo info;
    info.id = getId();
    info.name = getName();
    info.type = getType();
    info.status = status_;
    if (discovered_) {
        DeviceCapabilities caps;
        caps.name = "ESP32-WROOM-32D Development Board";
        caps.type = "Microcontroller (Xtensa Dual-Core 240MHz)";
        caps.firmware_version = "v4.4.2-idf";
        caps.supported_protocols = {"UART", "SPI", "I2C", "CAN", "WiFi 802.11b/g/n", "BLE 4.2"};
        caps.max_sample_rate_hz = 2000000;
        caps.adc_resolution_bits = 12;
        caps.gpio_pins = 36;
        info.capabilities = caps;
    }
    if (status_ == DeviceStatus::Connected) {
        TelemetryData data;
        data.cpu_usage_percent = 28.4;
        data.temperature_celsius = 44.2;
        data.voltage_v = 3.31;
        data.current_ma = 95.0;
        data.uptime_seconds = 120;
        data.free_memory_bytes = 184320;
        data.status_message = "ESP-IDF v4.4.2 Active";
        info.telemetry = data;
    }
    return info;
}

} // namespace hardware
} // namespace workbench
