#include "hardware/jtag_adapter.h"

namespace workbench {
namespace hardware {

JTAGAdapter::JTAGAdapter()
    : status_(DeviceStatus::Disconnected),
      discovered_(false),
      connect_attempts_(0),
      rng_(98765) {}

Result<DeviceInfo> JTAGAdapter::discover() {
    discovered_ = true;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<DeviceCapabilities> JTAGAdapter::getCapabilities() {
    DeviceCapabilities caps;
    caps.name = "SEGGER J-Link BASE / OpenOCD CMSIS-DAP Debug Probe";
    caps.type = "Hardware Debug Probe (IEEE 1149.1 / SWD)";
    caps.firmware_version = "J-Link ARM V11 compiled May 2024";
    caps.supported_protocols = {"JTAG (TCK/TMS/TDI/TDO/TRST)", "SWD (SWCLK/SWDIO)", "SWO Trace"};
    caps.max_sample_rate_hz = 15000000; // 15 MHz TCK
    caps.adc_resolution_bits = 0; // Not applicable
    caps.gpio_pins = 20; // 20-pin 0.1" standard JTAG header
    return Result<DeviceCapabilities>::Ok(caps);
}

Result<DeviceInfo> JTAGAdapter::connect() {
    if (!discovered_) {
        return Result<DeviceInfo>::Err(ErrorCode::HardwareError, "JTAG Adapter must be discovered before connecting.");
    }
    
    status_ = DeviceStatus::Connecting;
    connect_attempts_++;

    // Recoverable failure simulation: fail on 5th attempt
    if (connect_attempts_ % 5 == 0) {
        status_ = DeviceStatus::Error;
        return Result<DeviceInfo>::Err(ErrorCode::HardwareError, 
            "Target Voltage Sense Error (VTref = 0.0V): No target board power detected on Pin 1. Verify target power.");
    }

    status_ = DeviceStatus::Connected;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<DeviceInfo> JTAGAdapter::disconnect() {
    status_ = DeviceStatus::Disconnected;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<TelemetryData> JTAGAdapter::getTelemetry() {
    if (status_ != DeviceStatus::Connected) {
        return Result<TelemetryData>::Err(ErrorCode::HardwareError, "JTAG Adapter not connected.");
    }

    std::uniform_real_distribution<double> dist_vtref(3.28, 3.32);
    std::uniform_real_distribution<double> dist_temp(35.0, 39.0);

    TelemetryData data;
    data.cpu_usage_percent = 8.5;
    data.temperature_celsius = dist_temp(rng_);
    data.voltage_v = dist_vtref(rng_); // VTref target sense
    data.current_ma = 48.0; // Probe consumption
    data.uptime_seconds = 1450 + connect_attempts_ * 60;
    data.free_memory_bytes = 65536;
    data.status_message = "TAP Controller: Run-Test/Idle; Target IDCODE 0x4BA00477 (Cortex-M4/Artix-7 TAP recognized)";

    return Result<TelemetryData>::Ok(data);
}

DeviceStatus JTAGAdapter::getStatus() const { return status_; }
std::string JTAGAdapter::getId() const { return "segger_jlink"; }
std::string JTAGAdapter::getName() const { return "SEGGER J-Link Debug Probe"; }
std::string JTAGAdapter::getType() const { return "JTAG Adapter"; }

DeviceInfo JTAGAdapter::buildInfo() const {
    DeviceInfo info;
    info.id = getId();
    info.name = getName();
    info.type = getType();
    info.status = status_;
    if (discovered_) {
        DeviceCapabilities caps;
        caps.name = "SEGGER J-Link Debug Probe";
        caps.type = "Hardware Debug Probe (IEEE 1149.1 / SWD)";
        caps.firmware_version = "J-Link ARM V11";
        caps.supported_protocols = {"JTAG", "SWD", "SWO"};
        caps.max_sample_rate_hz = 15000000;
        caps.adc_resolution_bits = 0;
        caps.gpio_pins = 20;
        info.capabilities = caps;
    }
    if (status_ == DeviceStatus::Connected) {
        TelemetryData data;
        data.cpu_usage_percent = 8.5;
        data.temperature_celsius = 36.4;
        data.voltage_v = 3.30;
        data.current_ma = 48.0;
        data.uptime_seconds = 500;
        data.free_memory_bytes = 65536;
        data.status_message = "TAP Controller: Run-Test/Idle; Target Recognized";
        info.telemetry = data;
    }
    return info;
}

} // namespace hardware
} // namespace workbench
