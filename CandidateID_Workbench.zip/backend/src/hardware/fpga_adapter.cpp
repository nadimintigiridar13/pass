#include "hardware/fpga_adapter.h"

namespace workbench {
namespace hardware {

FPGABoardAdapter::FPGABoardAdapter()
    : status_(DeviceStatus::Disconnected),
      discovered_(false),
      connect_attempts_(0),
      rng_(54321) {}

Result<DeviceInfo> FPGABoardAdapter::discover() {
    discovered_ = true;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<DeviceCapabilities> FPGABoardAdapter::getCapabilities() {
    DeviceCapabilities caps;
    caps.name = "Xilinx Artix-7 XC7A35T (Basys 3 / Arty A7)";
    caps.type = "FPGA Board (33,280 Logic Cells, 50 Block RAMs)";
    caps.firmware_version = "Bitstream: v2.1_thermal_accel";
    caps.supported_protocols = {"AXI-Lite", "SPI", "UART", "PMOD", "JTAG Tap"};
    caps.max_sample_rate_hz = 100000000;
    caps.adc_resolution_bits = 12; // Xilinx XADC
    caps.gpio_pins = 64;
    return Result<DeviceCapabilities>::Ok(caps);
}

Result<DeviceInfo> FPGABoardAdapter::connect() {
    if (!discovered_) {
        return Result<DeviceInfo>::Err(ErrorCode::HardwareError, "FPGA must be discovered before connecting.");
    }
    
    status_ = DeviceStatus::Connecting;
    connect_attempts_++;

    // Recoverable failure simulation: fail on 2nd attempt
    if (connect_attempts_ % 4 == 2) {
        status_ = DeviceStatus::Error;
        return Result<DeviceInfo>::Err(ErrorCode::HardwareError, 
            "FPGA FTDI FT2232H USB enumeration failure: Device in low-power sleep. Retry connect to re-enumerate.");
    }

    status_ = DeviceStatus::Connected;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<DeviceInfo> FPGABoardAdapter::disconnect() {
    status_ = DeviceStatus::Disconnected;
    return Result<DeviceInfo>::Ok(buildInfo());
}

Result<TelemetryData> FPGABoardAdapter::getTelemetry() {
    if (status_ != DeviceStatus::Connected) {
        return Result<TelemetryData>::Err(ErrorCode::HardwareError, "FPGA not connected.");
    }

    std::uniform_real_distribution<double> dist_temp(52.0, 59.8);
    std::uniform_real_distribution<double> dist_cpu(40.0, 85.0);
    std::uniform_real_distribution<double> dist_curr(320.0, 510.0);

    TelemetryData data;
    data.cpu_usage_percent = dist_cpu(rng_); // LUT utilization
    data.temperature_celsius = dist_temp(rng_); // XADC internal die temp
    data.voltage_v = 1.00; // VCCINT 1.0V core
    data.current_ma = dist_curr(rng_);
    data.uptime_seconds = 780 + connect_attempts_ * 45;
    data.free_memory_bytes = 45 * 36 * 1024 / 8; // Available Block RAM in bytes
    data.status_message = "DONE LED High; MMCM Phase-Locked at 100MHz; AXI Interconnect Active";

    return Result<TelemetryData>::Ok(data);
}

DeviceStatus FPGABoardAdapter::getStatus() const { return status_; }
std::string FPGABoardAdapter::getId() const { return "xilinx_artix7_fpga"; }
std::string FPGABoardAdapter::getName() const { return "Xilinx Artix-7 FPGA"; }
std::string FPGABoardAdapter::getType() const { return "FPGA"; }

DeviceInfo FPGABoardAdapter::buildInfo() const {
    DeviceInfo info;
    info.id = getId();
    info.name = getName();
    info.type = getType();
    info.status = status_;
    if (discovered_) {
        DeviceCapabilities caps;
        caps.name = "Xilinx Artix-7 XC7A35T";
        caps.type = "FPGA Board (33,280 Logic Cells)";
        caps.firmware_version = "Bitstream: v2.1_thermal_accel";
        caps.supported_protocols = {"AXI-Lite", "SPI", "UART", "PMOD", "JTAG Tap"};
        caps.max_sample_rate_hz = 100000000;
        caps.adc_resolution_bits = 12;
        caps.gpio_pins = 64;
        info.capabilities = caps;
    }
    if (status_ == DeviceStatus::Connected) {
        TelemetryData data;
        data.cpu_usage_percent = 54.0;
        data.temperature_celsius = 53.8;
        data.voltage_v = 1.00;
        data.current_ma = 410.0;
        data.uptime_seconds = 300;
        data.free_memory_bytes = 184320;
        data.status_message = "MMCM Locked @ 100MHz";
        info.telemetry = data;
    }
    return info;
}

} // namespace hardware
} // namespace workbench
