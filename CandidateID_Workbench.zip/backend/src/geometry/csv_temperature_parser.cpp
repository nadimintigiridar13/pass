#include "geometry/csv_temperature_parser.h"
#include "common/csv_utils.h"
#include "common/validation.h"
#include <cmath>
#include <limits>
#include <fstream>

namespace workbench {
namespace geometry {

Result<TemperatureData> parse_temperature_csv(const std::string& content) {
    auto csv_result = csv::parse_csv(content);
    if (csv_result.has_error()) {
        return Result<TemperatureData>::Err(csv_result.error().code, csv_result.error().message);
    }

    const auto& csv_data = csv_result.value();

    // Validate required columns
    const std::vector<std::string> required_cols = {
        "node_id", "x_m", "y_m", "z_m", "temperature_C"
    };

    std::vector<int> col_indices;
    for (const auto& col : required_cols) {
        int idx = csv_data.column_index(col);
        if (idx < 0) {
            return Result<TemperatureData>::Err(ErrorCode::ParseError,
                "Missing required column: '" + col + "'. "
                "Required columns: node_id, x_m, y_m, z_m, temperature_C");
        }
        col_indices.push_back(idx);
    }

    int idx_node_id = col_indices[0];
    int idx_x = col_indices[1];
    int idx_y = col_indices[2];
    int idx_z = col_indices[3];
    int idx_temp = col_indices[4];

    if (csv_data.num_rows() == 0) {
        return Result<TemperatureData>::Err(ErrorCode::ParseError,
            "CSV file has no data rows");
    }

    TemperatureData data;
    data.min_temperature = std::numeric_limits<double>::max();
    data.max_temperature = std::numeric_limits<double>::lowest();
    data.bounding_box.min_pt = Vec3(
        std::numeric_limits<double>::max(),
        std::numeric_limits<double>::max(),
        std::numeric_limits<double>::max());
    data.bounding_box.max_pt = Vec3(
        std::numeric_limits<double>::lowest(),
        std::numeric_limits<double>::lowest(),
        std::numeric_limits<double>::lowest());

    for (size_t row = 0; row < csv_data.num_rows(); ++row) {
        const auto& csv_row = csv_data.rows[row];

        TemperatureNode node;
        int node_id;
        if (!validation::try_parse_int(csv_row[idx_node_id], node_id)) {
            return Result<TemperatureData>::Err(ErrorCode::ParseError,
                "Row " + std::to_string(row + 2) + ": Invalid node_id: '" +
                csv_row[idx_node_id] + "'");
        }
        node.node_id = node_id;

        double x, y, z, temp;
        if (!validation::try_parse_double(csv_row[idx_x], x)) {
            return Result<TemperatureData>::Err(ErrorCode::ParseError,
                "Row " + std::to_string(row + 2) + ": Invalid x_m value: '" +
                csv_row[idx_x] + "'");
        }
        if (!validation::try_parse_double(csv_row[idx_y], y)) {
            return Result<TemperatureData>::Err(ErrorCode::ParseError,
                "Row " + std::to_string(row + 2) + ": Invalid y_m value: '" +
                csv_row[idx_y] + "'");
        }
        if (!validation::try_parse_double(csv_row[idx_z], z)) {
            return Result<TemperatureData>::Err(ErrorCode::ParseError,
                "Row " + std::to_string(row + 2) + ": Invalid z_m value: '" +
                csv_row[idx_z] + "'");
        }
        if (!validation::try_parse_double(csv_row[idx_temp], temp)) {
            return Result<TemperatureData>::Err(ErrorCode::ParseError,
                "Row " + std::to_string(row + 2) + ": Invalid temperature_C value: '" +
                csv_row[idx_temp] + "'");
        }

        node.x = x;
        node.y = y;
        node.z = z;
        node.temperature = temp;
        data.nodes.push_back(node);

        // Update bounds
        data.bounding_box.min_pt.x = std::min(data.bounding_box.min_pt.x, x);
        data.bounding_box.min_pt.y = std::min(data.bounding_box.min_pt.y, y);
        data.bounding_box.min_pt.z = std::min(data.bounding_box.min_pt.z, z);
        data.bounding_box.max_pt.x = std::max(data.bounding_box.max_pt.x, x);
        data.bounding_box.max_pt.y = std::max(data.bounding_box.max_pt.y, y);
        data.bounding_box.max_pt.z = std::max(data.bounding_box.max_pt.z, z);
        data.min_temperature = std::min(data.min_temperature, temp);
        data.max_temperature = std::max(data.max_temperature, temp);
    }

    return Result<TemperatureData>::Ok(std::move(data));
}

Result<TemperatureData> parse_temperature_csv_file(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        return Result<TemperatureData>::Err(ErrorCode::FileReadError,
            "Cannot open CSV file: " + filepath);
    }
    std::string content((std::istreambuf_iterator<char>(file)),
                         std::istreambuf_iterator<char>());
    return parse_temperature_csv(content);
}

} // namespace geometry
} // namespace workbench
