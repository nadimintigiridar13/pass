#include "geometry/stl_parser.h"
#include <sstream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <limits>

namespace workbench {
namespace geometry {

namespace {

std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && std::isspace(static_cast<unsigned char>(s[start]))) ++start;
    size_t end = s.size();
    while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1]))) --end;
    return s.substr(start, end - start);
}

std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
        [](unsigned char c) { return std::tolower(c); });
    return s;
}

bool starts_with(const std::string& s, const std::string& prefix) {
    if (s.size() < prefix.size()) return false;
    return s.compare(0, prefix.size(), prefix) == 0;
}

bool is_likely_binary_stl(const std::string& content) {
    // Binary STL has 80-byte header + 4-byte triangle count
    // Check for null bytes in the first 80 characters that would indicate binary
    if (content.size() < 84) return false;

    // If it starts with "solid" and contains "facet" it's likely ASCII
    std::string lower_start = to_lower(content.substr(0, std::min(content.size(), size_t(80))));
    if (starts_with(trim(lower_start), "solid")) {
        // Check if there is "facet" or "endsolid" somewhere — likely ASCII
        std::string lower_content = to_lower(content.substr(0, std::min(content.size(), size_t(1000))));
        if (lower_content.find("facet") != std::string::npos ||
            lower_content.find("endsolid") != std::string::npos) {
            return false;
        }
    }

    // Check for null bytes which indicate binary
    for (size_t i = 0; i < std::min(content.size(), size_t(80)); ++i) {
        if (content[i] == '\0') return true;
    }

    return false;
}

} // anonymous namespace

Result<STLData> parse_stl(const std::string& content) {
    if (content.empty()) {
        return Result<STLData>::Err(ErrorCode::ParseError, "STL content is empty");
    }

    if (is_likely_binary_stl(content)) {
        return Result<STLData>::Err(ErrorCode::ParseError,
            "Binary STL format is not supported. Please provide ASCII STL.");
    }

    STLData data;
    data.bounding_box.min_pt = Vec3(
        std::numeric_limits<double>::max(),
        std::numeric_limits<double>::max(),
        std::numeric_limits<double>::max());
    data.bounding_box.max_pt = Vec3(
        std::numeric_limits<double>::lowest(),
        std::numeric_limits<double>::lowest(),
        std::numeric_limits<double>::lowest());

    std::istringstream stream(content);
    std::string line;
    int line_num = 0;

    // Parse "solid [name]"
    bool found_solid = false;
    while (std::getline(stream, line)) {
        ++line_num;
        std::string trimmed = trim(line);
        if (trimmed.empty()) continue;
        std::string lower = to_lower(trimmed);
        if (starts_with(lower, "solid")) {
            found_solid = true;
            // Extract name (everything after "solid ")
            if (trimmed.size() > 6) {
                data.solid_name = trim(trimmed.substr(6));
            }
            break;
        } else {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) + ": Expected 'solid', got: " + trimmed);
        }
    }

    if (!found_solid) {
        return Result<STLData>::Err(ErrorCode::ParseError,
            "No 'solid' keyword found in STL file");
    }

    // Parse facets
    bool found_endsolid = false;
    while (std::getline(stream, line)) {
        ++line_num;
        std::string trimmed = trim(line);
        if (trimmed.empty()) continue;
        std::string lower = to_lower(trimmed);

        if (starts_with(lower, "endsolid")) {
            found_endsolid = true;
            break;
        }

        // Expect "facet normal nx ny nz"
        if (!starts_with(lower, "facet normal")) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) +
                ": Expected 'facet normal' or 'endsolid', got: " + trimmed);
        }

        Triangle tri;

        // Parse normal
        std::istringstream nstream(trimmed.substr(12)); // after "facet normal"
        double nx, ny, nz;
        if (!(nstream >> nx >> ny >> nz)) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) + ": Invalid normal values");
        }
        if (!std::isfinite(nx) || !std::isfinite(ny) || !std::isfinite(nz)) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) + ": Normal contains NaN or Inf");
        }
        tri.normal = Vec3(nx, ny, nz);

        // Expect "outer loop"
        if (!std::getline(stream, line)) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Unexpected end of file, expected 'outer loop'");
        }
        ++line_num;
        trimmed = trim(line);
        lower = to_lower(trimmed);
        if (!starts_with(lower, "outer loop")) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) + ": Expected 'outer loop', got: " + trimmed);
        }

        // Parse 3 vertices
        for (int vi = 0; vi < 3; ++vi) {
            if (!std::getline(stream, line)) {
                return Result<STLData>::Err(ErrorCode::ParseError,
                    "Unexpected end of file, expected 'vertex'");
            }
            ++line_num;
            trimmed = trim(line);
            lower = to_lower(trimmed);
            if (!starts_with(lower, "vertex")) {
                return Result<STLData>::Err(ErrorCode::ParseError,
                    "Line " + std::to_string(line_num) + ": Expected 'vertex', got: " + trimmed);
            }
            std::istringstream vstream(trimmed.substr(6));
            double vx, vy, vz;
            if (!(vstream >> vx >> vy >> vz)) {
                return Result<STLData>::Err(ErrorCode::ParseError,
                    "Line " + std::to_string(line_num) + ": Invalid vertex values");
            }
            if (!std::isfinite(vx) || !std::isfinite(vy) || !std::isfinite(vz)) {
                return Result<STLData>::Err(ErrorCode::ParseError,
                    "Line " + std::to_string(line_num) + ": Vertex contains NaN or Inf");
            }
            tri.vertices[vi] = Vec3(vx, vy, vz);

            // Update bounding box
            data.bounding_box.min_pt.x = std::min(data.bounding_box.min_pt.x, vx);
            data.bounding_box.min_pt.y = std::min(data.bounding_box.min_pt.y, vy);
            data.bounding_box.min_pt.z = std::min(data.bounding_box.min_pt.z, vz);
            data.bounding_box.max_pt.x = std::max(data.bounding_box.max_pt.x, vx);
            data.bounding_box.max_pt.y = std::max(data.bounding_box.max_pt.y, vy);
            data.bounding_box.max_pt.z = std::max(data.bounding_box.max_pt.z, vz);
        }

        // Expect "endloop"
        if (!std::getline(stream, line)) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Unexpected end of file, expected 'endloop'");
        }
        ++line_num;
        trimmed = trim(line);
        lower = to_lower(trimmed);
        if (!starts_with(lower, "endloop")) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) + ": Expected 'endloop', got: " + trimmed);
        }

        // Expect "endfacet"
        if (!std::getline(stream, line)) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Unexpected end of file, expected 'endfacet'");
        }
        ++line_num;
        trimmed = trim(line);
        lower = to_lower(trimmed);
        if (!starts_with(lower, "endfacet")) {
            return Result<STLData>::Err(ErrorCode::ParseError,
                "Line " + std::to_string(line_num) + ": Expected 'endfacet', got: " + trimmed);
        }

        data.triangles.push_back(tri);
    }

    if (!found_endsolid) {
        return Result<STLData>::Err(ErrorCode::ParseError,
            "Missing 'endsolid' keyword");
    }

    if (data.triangles.empty()) {
        return Result<STLData>::Err(ErrorCode::ParseError,
            "STL file contains no triangles");
    }

    data.triangle_count = data.triangles.size();
    return Result<STLData>::Ok(std::move(data));
}

Result<STLData> parse_stl_file(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        return Result<STLData>::Err(ErrorCode::FileReadError,
            "Cannot open STL file: " + filepath);
    }
    std::string content((std::istreambuf_iterator<char>(file)),
                         std::istreambuf_iterator<char>());
    return parse_stl(content);
}

} // namespace geometry
} // namespace workbench
