#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#endif

#include "api/server.h"
#include "httplib.h"
#include "nlohmann/json.hpp"

#include "geometry/stl_parser.h"
#include "geometry/csv_temperature_parser.h"
#include "thermal/thermal_solver.h"
#include "performance/benchmark.h"
#include "backpropagation/neural_network.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>

using json = nlohmann::json;

namespace workbench {
namespace api {

APIServer::APIServer(int port) : port_(port), server_(std::make_unique<httplib::Server>()) {}

APIServer::~APIServer() {
    stop();
}

void APIServer::setup_cors() {
    server_->set_pre_routing_handler([](const httplib::Request& req, httplib::Response& res) {
        res.set_header("Access-Control-Allow-Origin", "*");
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept");
        if (req.method == "OPTIONS") {
            res.status = 200;
            return httplib::Server::HandlerResponse::Handled;
        }
        return httplib::Server::HandlerResponse::Unhandled;
    });
}

void APIServer::setup_routes() {
    // ── Mount Frontend Static Web App ─────────────────────────────────
    if (std::filesystem::exists("frontend/dist")) {
        server_->set_mount_point("/", "frontend/dist");
    } else if (std::filesystem::exists("./dist")) {
        server_->set_mount_point("/", "./dist");
    }

    // ── Health & System Info ──────────────────────────────────────────
    server_->Get("/api/health", [](const httplib::Request&, httplib::Response& res) {
        json j;
        j["status"] = "ok";
        j["service"] = "Unified Engineering Workbench Backend";
        j["version"] = "1.0.0";
        j["cplusplus_standard"] = "C++17";
        res.set_content(j.dump(), "application/json");
    });

    server_->Get("/api/system/info", [](const httplib::Request&, httplib::Response& res) {
        std::string hw_info = performance::get_hardware_info();
        json j;
        j["hardware_info"] = hw_info;
        j["logical_cores"] = std::thread::hardware_concurrency();
        j["platform"] = "Windows 11 x64 / MinGW C++17";
        j["status"] = "online";
        res.set_content(j.dump(), "application/json");
    });

    // ── Task B: Geometry (ASCII STL & Temperature CSV) ───────────────────
    server_->Post("/api/geometry/parse-stl", [](const httplib::Request& req, httplib::Response& res) {
        std::string content = req.body;
        if (content.empty()) {
            json err;
            err["error"] = "Empty STL content provided.";
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        auto parse_res = geometry::parse_stl(content);
        if (!parse_res.ok()) {
            json err;
            err["error"] = parse_res.error().message;
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        const auto& stl = parse_res.value();
        json j_triangles = json::array();
        for (const auto& tri : stl.triangles) {
            json t;
            t["normal"] = json::array({tri.normal.x, tri.normal.y, tri.normal.z});
            t["vertices"] = json::array({
                json::array({tri.vertices[0].x, tri.vertices[0].y, tri.vertices[0].z}),
                json::array({tri.vertices[1].x, tri.vertices[1].y, tri.vertices[1].z}),
                json::array({tri.vertices[2].x, tri.vertices[2].y, tri.vertices[2].z})
            });
            j_triangles.push_back(t);
        }

        json out;
        out["solid_name"] = stl.solid_name;
        out["triangle_count"] = stl.triangle_count;
        out["file_size"] = content.size();
        out["bounding_box"] = {
            {"min", json::array({stl.bounding_box.min_pt.x, stl.bounding_box.min_pt.y, stl.bounding_box.min_pt.z})},
            {"max", json::array({stl.bounding_box.max_pt.x, stl.bounding_box.max_pt.y, stl.bounding_box.max_pt.z})}
        };
        out["triangles"] = j_triangles;
        res.set_content(out.dump(), "application/json");
    });

    server_->Post("/api/geometry/parse-csv", [](const httplib::Request& req, httplib::Response& res) {
        std::string content = req.body;
        if (content.empty()) {
            json err;
            err["error"] = "Empty CSV content provided.";
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        auto parse_res = geometry::parse_temperature_csv(content);
        if (!parse_res.ok()) {
            json err;
            err["error"] = parse_res.error().message;
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        const auto& data = parse_res.value();
        json j_nodes = json::array();
        for (const auto& n : data.nodes) {
            json jn;
            jn["node_id"] = n.node_id;
            jn["x"] = n.x;
            jn["y"] = n.y;
            jn["z"] = n.z;
            jn["temperature"] = n.temperature;
            j_nodes.push_back(jn);
        }

        json out;
        out["node_count"] = data.nodes.size();
        out["min_temperature"] = data.min_temperature;
        out["max_temperature"] = data.max_temperature;
        out["bounding_box"] = {
            {"min", json::array({data.bounding_box.min_pt.x, data.bounding_box.min_pt.y, data.bounding_box.min_pt.z})},
            {"max", json::array({data.bounding_box.max_pt.x, data.bounding_box.max_pt.y, data.bounding_box.max_pt.z})}
        };
        out["nodes"] = j_nodes;
        res.set_content(out.dump(), "application/json");
    });

    // ── Task C: 1D Steady-State Thermal FEA Solver ───────────────────────
    server_->Post("/api/thermal/solve", [](const httplib::Request& req, httplib::Response& res) {
        ThermalParams params;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("L")) params.L = j["L"].get<double>();
                if (j.contains("A")) params.A = j["A"].get<double>();
                if (j.contains("k")) params.k = j["k"].get<double>();
                if (j.contains("q")) params.q = j["q"].get<double>();
                if (j.contains("T_left")) params.T_left = j["T_left"].get<double>();
                if (j.contains("T_right")) params.T_right = j["T_right"].get<double>();
                if (j.contains("num_elements")) params.num_elements = j["num_elements"].get<int>();
            }
        } catch (const std::exception& e) {
            json err;
            err["error"] = std::string("Malformed JSON: ") + e.what();
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        auto solve_res = thermal::solve(params);
        if (!solve_res.ok()) {
            json err;
            err["error"] = solve_res.error().message;
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        const auto& r = solve_res.value();
        json j_nodes = json::array();
        for (size_t i = 0; i < r.node_positions.size(); ++i) {
            json jn;
            jn["position"] = r.node_positions[i];
            jn["temperature"] = r.temperatures[i];
            jn["exact_temperature"] = r.exact_temperatures[i];
            j_nodes.push_back(jn);
        }

        json j_midpoints = json::array();
        for (size_t i = 0; i < r.midpoint_positions.size(); ++i) {
            json jm;
            jm["position"] = r.midpoint_positions[i];
            jm["fe_temp"] = r.midpoint_fe_temps[i];
            jm["exact_temp"] = r.midpoint_exact_temps[i];
            jm["error"] = r.midpoint_errors[i];
            j_midpoints.push_back(jm);
        }

        json out;
        out["num_elements"] = r.num_elements;
        out["max_midpoint_error"] = r.max_error;
        out["parameters"] = {
            {"L", r.params.L},
            {"A", r.params.A},
            {"k", r.params.k},
            {"q", r.params.q},
            {"T_left", r.params.T_left},
            {"T_right", r.params.T_right}
        };
        out["nodes"] = j_nodes;
        out["midpoints"] = j_midpoints;
        res.set_content(out.dump(), "application/json");
    });

    server_->Post("/api/thermal/convergence", [](const httplib::Request& req, httplib::Response& res) {
        ThermalParams base_params;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("L")) base_params.L = j["L"].get<double>();
                if (j.contains("A")) base_params.A = j["A"].get<double>();
                if (j.contains("k")) base_params.k = j["k"].get<double>();
                if (j.contains("q")) base_params.q = j["q"].get<double>();
                if (j.contains("T_left")) base_params.T_left = j["T_left"].get<double>();
                if (j.contains("T_right")) base_params.T_right = j["T_right"].get<double>();
            }
        } catch (...) {}

        std::vector<int> mesh_sizes = {10, 20, 40, 80};
        json convergence_data = json::array();
        for (int n : mesh_sizes) {
            base_params.num_elements = n;
            auto sol = thermal::solve(base_params);
            if (sol.ok()) {
                const auto& r = sol.value();
                json cp;
                cp["num_elements"] = n;
                cp["element_size"] = base_params.L / n;
                cp["max_midpoint_error"] = r.max_error;
                convergence_data.push_back(cp);
            }
        }

        json out;
        out["convergence"] = convergence_data;
        res.set_content(out.dump(), "application/json");
    });

    // ── Task D: Multicore / Multithreaded Execution ──────────────────────
    server_->Post("/api/performance/benchmark", [](const httplib::Request& req, httplib::Response& res) {
        int num_cases = 100;
        int mesh_size = 40;
        int max_workers = 4;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("num_cases")) num_cases = j["num_cases"].get<int>();
                if (j.contains("mesh_size")) mesh_size = j["mesh_size"].get<int>();
                if (j.contains("max_workers")) max_workers = j["max_workers"].get<int>();
            }
        } catch (...) {}

        if (num_cases < 5) num_cases = 5;
        if (num_cases > 2000) num_cases = 2000;
        if (mesh_size < 5) mesh_size = 5;
        if (mesh_size > 500) mesh_size = 500;
        if (max_workers < 1) max_workers = 1;
        if (max_workers > 16) max_workers = 16;

        json j_runs = json::array();
        for (int w = 1; w <= max_workers; ++w) {
            auto b_res = performance::run_benchmark(num_cases, mesh_size, w);
            if (b_res.ok()) {
                const auto& run = b_res.value();
                json jr;
                jr["workers"] = run.num_workers;
                jr["serial_time_ms"] = run.serial_time_ms;
                jr["parallel_time_ms"] = run.parallel_time_ms;
                jr["speedup"] = run.speedup;
                jr["efficiency"] = run.efficiency;
                jr["max_disagreement"] = run.max_disagreement;
                jr["results_agree"] = run.results_agree;
                j_runs.push_back(jr);
            }
        }

        json out;
        out["num_cases"] = num_cases;
        out["mesh_size"] = mesh_size;
        out["hardware_info"] = performance::get_hardware_info();
        out["logical_cpus"] = std::thread::hardware_concurrency();
        out["benchmark_runs"] = j_runs;
        res.set_content(out.dump(), "application/json");
    });

    // ── Task E: Embedded-System Hardware Mock Adapters ────────────────────
    server_->Get("/api/hardware/devices", [this](const httplib::Request&, httplib::Response& res) {
        auto dev_to_json = [](hardware::IDeviceAdapter& dev) {
            json j;
            j["id"] = dev.getId();
            j["name"] = dev.getName();
            j["type"] = dev.getType();
            j["status"] = workbench::device_status_to_string(dev.getStatus());
            
            auto caps = dev.getCapabilities();
            if (caps.ok()) {
                const auto& c = caps.value();
                json cj;
                cj["name"] = c.name;
                cj["firmware_version"] = c.firmware_version;
                cj["supported_protocols"] = c.supported_protocols;
                cj["max_sample_rate_hz"] = c.max_sample_rate_hz;
                cj["adc_resolution_bits"] = c.adc_resolution_bits;
                cj["gpio_pins"] = c.gpio_pins;
                j["capabilities"] = cj;
            }
            if (dev.getStatus() == DeviceStatus::Connected) {
                auto telem = dev.getTelemetry();
                if (telem.ok()) {
                    const auto& t = telem.value();
                    json tj;
                    tj["cpu_usage_percent"] = t.cpu_usage_percent;
                    tj["temperature_celsius"] = t.temperature_celsius;
                    tj["voltage_v"] = t.voltage_v;
                    tj["current_ma"] = t.current_ma;
                    tj["uptime_seconds"] = t.uptime_seconds;
                    tj["free_memory_bytes"] = t.free_memory_bytes;
                    tj["status_message"] = t.status_message;
                    j["telemetry"] = tj;
                }
            }
            return j;
        };

        json devices = json::array();
        devices.push_back(dev_to_json(esp32_adapter_));
        devices.push_back(dev_to_json(fpga_adapter_));
        devices.push_back(dev_to_json(jtag_adapter_));

        res.set_content(devices.dump(), "application/json");
    });

    server_->Post(R"(/api/hardware/([^/]+)/discover)", [this](const httplib::Request& req, httplib::Response& res) {
        std::string dev_id = req.matches[1];
        hardware::IDeviceAdapter* target = nullptr;
        if (dev_id == esp32_adapter_.getId()) target = &esp32_adapter_;
        else if (dev_id == fpga_adapter_.getId()) target = &fpga_adapter_;
        else if (dev_id == jtag_adapter_.getId()) target = &jtag_adapter_;

        if (!target) {
            json err;
            err["error"] = "Unknown hardware device ID: " + dev_id;
            res.status = 404;
            res.set_content(err.dump(), "application/json");
            return;
        }

        auto disc_res = target->discover();
        if (!disc_res.ok()) {
            json err;
            err["error"] = disc_res.error().message;
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        json out;
        out["status"] = "Discovered";
        out["id"] = target->getId();
        out["name"] = target->getName();
        res.set_content(out.dump(), "application/json");
    });

    server_->Post(R"(/api/hardware/([^/]+)/connect)", [this](const httplib::Request& req, httplib::Response& res) {
        std::string dev_id = req.matches[1];
        hardware::IDeviceAdapter* target = nullptr;
        if (dev_id == esp32_adapter_.getId()) target = &esp32_adapter_;
        else if (dev_id == fpga_adapter_.getId()) target = &fpga_adapter_;
        else if (dev_id == jtag_adapter_.getId()) target = &jtag_adapter_;

        if (!target) {
            json err;
            err["error"] = "Unknown hardware device ID: " + dev_id;
            res.status = 404;
            res.set_content(err.dump(), "application/json");
            return;
        }

        auto conn_res = target->connect();
        if (!conn_res.ok()) {
            json err;
            err["error"] = conn_res.error().message;
            err["device_status"] = "Error";
            res.status = 500;
            res.set_content(err.dump(), "application/json");
            return;
        }

        json out;
        out["status"] = "Connected";
        out["id"] = target->getId();
        out["name"] = target->getName();
        res.set_content(out.dump(), "application/json");
    });

    server_->Post(R"(/api/hardware/([^/]+)/disconnect)", [this](const httplib::Request& req, httplib::Response& res) {
        std::string dev_id = req.matches[1];
        hardware::IDeviceAdapter* target = nullptr;
        if (dev_id == esp32_adapter_.getId()) target = &esp32_adapter_;
        else if (dev_id == fpga_adapter_.getId()) target = &fpga_adapter_;
        else if (dev_id == jtag_adapter_.getId()) target = &jtag_adapter_;

        if (!target) {
            json err;
            err["error"] = "Unknown hardware device ID: " + dev_id;
            res.status = 404;
            res.set_content(err.dump(), "application/json");
            return;
        }

        target->disconnect();
        json out;
        out["status"] = "Disconnected";
        out["id"] = target->getId();
        res.set_content(out.dump(), "application/json");
    });

    server_->Get(R"(/api/hardware/([^/]+)/telemetry)", [this](const httplib::Request& req, httplib::Response& res) {
        std::string dev_id = req.matches[1];
        hardware::IDeviceAdapter* target = nullptr;
        if (dev_id == esp32_adapter_.getId()) target = &esp32_adapter_;
        else if (dev_id == fpga_adapter_.getId()) target = &fpga_adapter_;
        else if (dev_id == jtag_adapter_.getId()) target = &jtag_adapter_;

        if (!target) {
            json err;
            err["error"] = "Unknown hardware device ID: " + dev_id;
            res.status = 404;
            res.set_content(err.dump(), "application/json");
            return;
        }

        auto telem_res = target->getTelemetry();
        if (!telem_res.ok()) {
            json err;
            err["error"] = telem_res.error().message;
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        const auto& t = telem_res.value();
        json out;
        out["cpu_usage_percent"] = t.cpu_usage_percent;
        out["temperature_celsius"] = t.temperature_celsius;
        out["voltage_v"] = t.voltage_v;
        out["current_ma"] = t.current_ma;
        out["uptime_seconds"] = t.uptime_seconds;
        out["free_memory_bytes"] = t.free_memory_bytes;
        out["status_message"] = t.status_message;
        res.set_content(out.dump(), "application/json");
    });

    // ── Task F: Handwritten Backpropagation ─────────────────────────────
    server_->Post("/api/backprop/forward", [](const httplib::Request& req, httplib::Response& res) {
        NeuralNetParams params;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("w")) params.w = j["w"].get<double>();
                if (j.contains("b")) params.b = j["b"].get<double>();
                if (j.contains("v")) params.v = j["v"].get<double>();
                if (j.contains("c")) params.c = j["c"].get<double>();
                if (j.contains("x")) params.x = j["x"].get<double>();
                if (j.contains("y")) params.y = j["y"].get<double>();
                if (j.contains("alpha")) params.alpha = j["alpha"].get<double>();
            }
        } catch (...) {}

        auto fwd = backpropagation::forward(params);
        json out;
        out["h"] = fwd.h;
        out["y_hat"] = fwd.y_hat;
        out["loss"] = fwd.loss;
        out["error"] = fwd.y_hat - params.y;
        out["parameters"] = {
            {"w", params.w}, {"b", params.b}, {"v", params.v}, {"c", params.c},
            {"x", params.x}, {"y", params.y}, {"alpha", params.alpha}
        };
        res.set_content(out.dump(), "application/json");
    });

    server_->Post("/api/backprop/gradients", [](const httplib::Request& req, httplib::Response& res) {
        NeuralNetParams params;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("w")) params.w = j["w"].get<double>();
                if (j.contains("b")) params.b = j["b"].get<double>();
                if (j.contains("v")) params.v = j["v"].get<double>();
                if (j.contains("c")) params.c = j["c"].get<double>();
                if (j.contains("x")) params.x = j["x"].get<double>();
                if (j.contains("y")) params.y = j["y"].get<double>();
                if (j.contains("alpha")) params.alpha = j["alpha"].get<double>();
            }
        } catch (...) {}

        auto grads = backpropagation::compute_gradients(params);
        json out;
        out["dJ_dw"] = grads.dJ_dw;
        out["dJ_db"] = grads.dJ_db;
        out["dJ_dv"] = grads.dJ_dv;
        out["dJ_dc"] = grads.dJ_dc;
        out["forward"] = {
            {"h", grads.forward.h},
            {"y_hat", grads.forward.y_hat},
            {"loss", grads.forward.loss}
        };
        res.set_content(out.dump(), "application/json");
    });

    server_->Post("/api/backprop/verify", [](const httplib::Request& req, httplib::Response& res) {
        NeuralNetParams params;
        double epsilon = 1e-6;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("w")) params.w = j["w"].get<double>();
                if (j.contains("b")) params.b = j["b"].get<double>();
                if (j.contains("v")) params.v = j["v"].get<double>();
                if (j.contains("c")) params.c = j["c"].get<double>();
                if (j.contains("x")) params.x = j["x"].get<double>();
                if (j.contains("y")) params.y = j["y"].get<double>();
                if (j.contains("alpha")) params.alpha = j["alpha"].get<double>();
                if (j.contains("epsilon")) epsilon = j["epsilon"].get<double>();
            }
        } catch (...) {}

        auto v = backpropagation::verify_gradients(params, epsilon);
        json out;
        out["passed"] = v.passed;
        out["max_error"] = v.max_error;
        out["tolerance"] = 1e-5;
        out["epsilon"] = epsilon;
        out["gradients"] = {
            {"w", {{"analytical", v.dJ_dw_analytical}, {"numerical", v.dJ_dw_numerical}, {"abs_error", v.dJ_dw_error}}},
            {"b", {{"analytical", v.dJ_db_analytical}, {"numerical", v.dJ_db_numerical}, {"abs_error", v.dJ_db_error}}},
            {"v", {{"analytical", v.dJ_dv_analytical}, {"numerical", v.dJ_dv_numerical}, {"abs_error", v.dJ_dv_error}}},
            {"c", {{"analytical", v.dJ_dc_analytical}, {"numerical", v.dJ_dc_numerical}, {"abs_error", v.dJ_dc_error}}}
        };
        res.set_content(out.dump(), "application/json");
    });

    server_->Post("/api/backprop/train", [](const httplib::Request& req, httplib::Response& res) {
        NeuralNetParams params;
        int num_steps = 100;
        try {
            if (!req.body.empty()) {
                auto j = json::parse(req.body);
                if (j.contains("w")) params.w = j["w"].get<double>();
                if (j.contains("b")) params.b = j["b"].get<double>();
                if (j.contains("v")) params.v = j["v"].get<double>();
                if (j.contains("c")) params.c = j["c"].get<double>();
                if (j.contains("x")) params.x = j["x"].get<double>();
                if (j.contains("y")) params.y = j["y"].get<double>();
                if (j.contains("alpha")) params.alpha = j["alpha"].get<double>();
                if (j.contains("num_steps")) num_steps = j["num_steps"].get<int>();
            }
        } catch (...) {}

        auto train_res = backpropagation::train(params, num_steps);
        json j_history = json::array();
        for (const auto& step : train_res.history) {
            json js;
            js["step"] = step.step;
            js["loss"] = step.loss;
            js["y_hat"] = step.y_hat;
            js["w"] = step.params.w;
            js["b"] = step.params.b;
            js["v"] = step.params.v;
            js["c"] = step.params.c;
            j_history.push_back(js);
        }

        json out;
        out["history"] = j_history;
        out["final_loss"] = train_res.final_loss;
        out["final_params"] = {
            {"w", train_res.final_params.w},
            {"b", train_res.final_params.b},
            {"v", train_res.final_params.v},
            {"c", train_res.final_params.c}
        };
        out["gradient_verification_passed"] = train_res.initial_verification.passed;
        res.set_content(out.dump(), "application/json");
    });
}

bool APIServer::start() {
    setup_cors();
    setup_routes();
    std::cout << "[API Server] Listening on http://localhost:" << port_ << "...\n" << std::flush;
    bool ret = server_->listen("0.0.0.0", port_);
    if (!ret) {
        std::cout << "[API Server] Binding to 0.0.0.0 failed, trying 127.0.0.1...\n" << std::flush;
        ret = server_->listen("127.0.0.1", port_);
    }
    if (!ret) {
        std::cerr << "[API Server ERROR] Both 0.0.0.0 and 127.0.0.1 failed on port " << port_ << "\n" << std::flush;
    }
    return ret;
}

void APIServer::stop() {
    if (server_ && server_->is_running()) {
        server_->stop();
    }
}

} // namespace api
} // namespace workbench
