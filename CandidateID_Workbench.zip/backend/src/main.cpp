#include "api/server.h"
#include <iostream>
#include <csignal>

static std::unique_ptr<workbench::api::APIServer> g_server;

void signal_handler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        std::cout << "\n[Unified Engineering Workbench] Shutting down server gracefully...\n";
        if (g_server) {
            g_server->stop();
        }
    }
}

int main(int argc, char* argv[]) {
    int port = 8080;
    if (argc > 1) {
        port = std::atoi(argv[1]);
        if (port <= 0 || port > 65535) port = 8080;
    }

    std::cout << "=========================================================\n";
    std::cout << " UNIFIED ENGINEERING WORKBENCH - BACKEND SERVER (C++17) \n";
    std::cout << " PASS SCIENCE WORKS | R&D Internship 2026-2027\n";
    std::cout << "=========================================================\n";
    std::cout << "Initializing REST API services on port " << port << "...\n" << std::flush;

    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);

    try {
        g_server = std::make_unique<workbench::api::APIServer>(port);
        g_server->start();
    } catch (const std::exception& e) {
        std::cerr << "[FATAL] Server error: " << e.what() << "\n";
        return 1;
    }

    std::cout << "[Unified Engineering Workbench] Server stopped.\n";
    return 0;
}
