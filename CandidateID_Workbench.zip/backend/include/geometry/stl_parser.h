#ifndef WORKBENCH_GEOMETRY_STL_PARSER_H
#define WORKBENCH_GEOMETRY_STL_PARSER_H

#include <string>
#include "common/types.h"

namespace workbench {
namespace geometry {

// Parse ASCII STL from string content
Result<STLData> parse_stl(const std::string& content);

// Parse ASCII STL from file
Result<STLData> parse_stl_file(const std::string& filepath);

} // namespace geometry
} // namespace workbench

#endif // WORKBENCH_GEOMETRY_STL_PARSER_H
