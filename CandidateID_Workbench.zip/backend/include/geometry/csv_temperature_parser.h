#ifndef WORKBENCH_GEOMETRY_CSV_TEMPERATURE_PARSER_H
#define WORKBENCH_GEOMETRY_CSV_TEMPERATURE_PARSER_H

#include <string>
#include "common/types.h"

namespace workbench {
namespace geometry {

// Parse ANSYS-style CSV temperature data from string content
// Required columns: node_id, x_m, y_m, z_m, temperature_C
Result<TemperatureData> parse_temperature_csv(const std::string& content);

// Parse from file
Result<TemperatureData> parse_temperature_csv_file(const std::string& filepath);

} // namespace geometry
} // namespace workbench

#endif // WORKBENCH_GEOMETRY_CSV_TEMPERATURE_PARSER_H
