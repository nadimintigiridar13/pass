#ifndef WORKBENCH_HARDWARE_MICROCONTROLLER_ADAPTER_H
#define WORKBENCH_HARDWARE_MICROCONTROLLER_ADAPTER_H

#include "hardware/adapter_interface.h"
#include <random>

namespace workbench {
namespace hardware {

class MicrocontrollerAdapter : public IDeviceAdapter {
public:
    MicrocontrollerAdapter();

    Result<DeviceInfo> discover() override;
    Result<DeviceCapabilities> getCapabilities() override;
    Result<DeviceInfo> connect() override;
    Result<DeviceInfo> disconnect() override;
    Result<TelemetryData> getTelemetry() override;
    DeviceStatus getStatus() const override;
    std::string getId() const override;
    std::string getName() const override;
    std::string getType() const override;

private:
    DeviceInfo buildInfo() const;

    DeviceStatus status_;
    bool discovered_;
    int connect_attempts_;
    std::mt19937 rng_;
};

} // namespace hardware
} // namespace workbench

#endif // WORKBENCH_HARDWARE_MICROCONTROLLER_ADAPTER_H
