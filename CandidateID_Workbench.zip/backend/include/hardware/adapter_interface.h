#ifndef WORKBENCH_HARDWARE_ADAPTER_INTERFACE_H
#define WORKBENCH_HARDWARE_ADAPTER_INTERFACE_H

#include "common/types.h"
#include <memory>
#include <string>

namespace workbench {
namespace hardware {

// Abstract interface for device adapters
class IDeviceAdapter {
public:
    virtual ~IDeviceAdapter() = default;

    // Discovery
    virtual Result<DeviceInfo> discover() = 0;

    // Capabilities
    virtual Result<DeviceCapabilities> getCapabilities() = 0;

    // Connection management
    virtual Result<DeviceInfo> connect() = 0;
    virtual Result<DeviceInfo> disconnect() = 0;

    // Telemetry
    virtual Result<TelemetryData> getTelemetry() = 0;

    // Status
    virtual DeviceStatus getStatus() const = 0;
    virtual std::string getId() const = 0;
    virtual std::string getName() const = 0;
    virtual std::string getType() const = 0;
};

} // namespace hardware
} // namespace workbench

#endif // WORKBENCH_HARDWARE_ADAPTER_INTERFACE_H
