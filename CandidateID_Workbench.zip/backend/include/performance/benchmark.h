#ifndef WORKBENCH_PERFORMANCE_BENCHMARK_H
#define WORKBENCH_PERFORMANCE_BENCHMARK_H

#include "common/types.h"
#include <vector>

namespace workbench {
namespace performance {

// Run serial and parallel benchmark
// num_cases: number of thermal cases
// mesh_size: elements per case
// max_workers: max parallel threads (1-4)
// Returns timing and agreement data
Result<BenchmarkTiming> run_benchmark(int num_cases, int mesh_size, int max_workers);

// Get hardware info string
std::string get_hardware_info();

} // namespace performance
} // namespace workbench

#endif // WORKBENCH_PERFORMANCE_BENCHMARK_H
