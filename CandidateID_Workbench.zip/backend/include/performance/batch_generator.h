#ifndef WORKBENCH_PERFORMANCE_BATCH_GENERATOR_H
#define WORKBENCH_PERFORMANCE_BATCH_GENERATOR_H

#include <vector>
#include "common/types.h"

namespace workbench {
namespace performance {

// Generate a batch of thermal cases with varied k and q
// Uses a fixed random seed for reproducibility
std::vector<ThermalParams> generate_batch(int num_cases, int mesh_size,
                                           unsigned int seed = 42);

} // namespace performance
} // namespace workbench

#endif // WORKBENCH_PERFORMANCE_BATCH_GENERATOR_H
