#ifndef WORKBENCH_BACKPROPAGATION_NEURAL_NETWORK_H
#define WORKBENCH_BACKPROPAGATION_NEURAL_NETWORK_H

#include "common/types.h"

namespace workbench {
namespace backpropagation {

// Forward propagation: computes h, y_hat, loss J
ForwardResult forward(const NeuralNetParams& params);

// Compute analytical gradients via chain rule
GradientResult compute_gradients(const NeuralNetParams& params);

// Numerical gradient verification using central finite differences (epsilon = 1e-6)
GradientVerification verify_gradients(const NeuralNetParams& params, double epsilon = 1e-6);

// Perform 1 single gradient descent update step
NeuralNetParams step(const NeuralNetParams& params, const GradientResult& grads);

// Train for specified number of steps (default 100)
TrainingResult train(NeuralNetParams initial_params, int num_steps = 100);

} // namespace backpropagation
} // namespace workbench

#endif // WORKBENCH_BACKPROPAGATION_NEURAL_NETWORK_H
