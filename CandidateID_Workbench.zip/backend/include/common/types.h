#ifndef WORKBENCH_COMMON_TYPES_H
#define WORKBENCH_COMMON_TYPES_H

#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <array>
#include <cstdint>
#include <stdexcept>

namespace workbench {

// ── Error types ────────────────────────────────────────────────────────────────

enum class ErrorCode {
    None = 0,
    InvalidInput,
    ParseError,
    FileNotFound,
    FileReadError,
    SolverError,
    HardwareError,
    NetworkError,
    InternalError,
    ValidationError
};

struct Error {
    ErrorCode code;
    std::string message;

    Error() : code(ErrorCode::None) {}
    Error(ErrorCode c, const std::string& msg) : code(c), message(msg) {}

    bool ok() const { return code == ErrorCode::None; }
    operator bool() const { return !ok(); } // true means error exists
};

// ── Result<T> template ─────────────────────────────────────────────────────────

template <typename T>
class Result {
public:
    static Result<T> Ok(T value) {
        Result r;
        r.value_ = std::move(value);
        r.error_ = Error{};
        return r;
    }

    static Result<T> Err(ErrorCode code, const std::string& msg) {
        Result r;
        r.error_ = Error{code, msg};
        return r;
    }

    bool ok() const { return error_.ok(); }
    bool has_error() const { return !ok(); }

    const T& value() const {
        if (has_error()) throw std::runtime_error("Accessing value of error Result: " + error_.message);
        return value_;
    }

    T& value() {
        if (has_error()) throw std::runtime_error("Accessing value of error Result: " + error_.message);
        return value_;
    }

    T&& move_value() {
        if (has_error()) throw std::runtime_error("Accessing value of error Result: " + error_.message);
        return std::move(value_);
    }

    const Error& error() const { return error_; }

private:
    T value_;
    Error error_;
};

// ── 3D point / vector ──────────────────────────────────────────────────────────

struct Vec3 {
    double x = 0.0, y = 0.0, z = 0.0;

    Vec3() = default;
    Vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}
};

// ── Bounding box ───────────────────────────────────────────────────────────────

struct BoundingBox {
    Vec3 min_pt;
    Vec3 max_pt;
};

// ── Triangle ───────────────────────────────────────────────────────────────────

struct Triangle {
    Vec3 vertices[3];
    Vec3 normal;
};

// ── STL data ───────────────────────────────────────────────────────────────────

struct STLData {
    std::string solid_name;
    std::vector<Triangle> triangles;
    BoundingBox bounding_box;
    size_t triangle_count = 0;
};

// ── Temperature node ───────────────────────────────────────────────────────────

struct TemperatureNode {
    int node_id = 0;
    double x = 0.0, y = 0.0, z = 0.0;
    double temperature = 0.0;
};

struct TemperatureData {
    std::vector<TemperatureNode> nodes;
    BoundingBox bounding_box;
    double min_temperature = 0.0;
    double max_temperature = 0.0;
};

// ── Thermal solver data ────────────────────────────────────────────────────────

struct ThermalParams {
    double L = 1.0;            // Length [m]
    double A = 1e-4;           // Cross-sectional area [m²]
    double k = 10.0;           // Thermal conductivity [W/(m·K)]
    double q = 10000.0;        // Heat generation [W/m³]
    double T_left = 100.0;     // BC at x=0 [°C]
    double T_right = 20.0;     // BC at x=L [°C]
    int num_elements = 10;     // Number of elements
};

struct ThermalResult {
    std::vector<double> node_positions;    // x positions of nodes
    std::vector<double> temperatures;      // FEA nodal temperatures
    std::vector<double> exact_temperatures; // analytical at nodes
    std::vector<double> midpoint_positions; // element midpoints
    std::vector<double> midpoint_fe_temps;  // FE interpolated at midpoints
    std::vector<double> midpoint_exact_temps; // analytical at midpoints
    std::vector<double> midpoint_errors;   // |FE - exact| at midpoints
    double max_error = 0.0;               // max |error|
    int num_elements = 0;
    ThermalParams params;
};

struct ConvergencePoint {
    int num_elements;
    double max_error;
    double element_size;
};

struct ConvergenceResult {
    std::vector<ConvergencePoint> points;
    std::vector<ThermalResult> solutions;
};

// ── Performance / benchmark data ───────────────────────────────────────────────

struct BenchmarkTiming {
    double serial_time_ms = 0.0;
    double parallel_time_ms = 0.0;
    double speedup = 0.0;
    double efficiency = 0.0;
    int num_workers = 0;
    int num_cases = 0;
    int mesh_size = 0;
    int repetitions = 0;
    double max_disagreement = 0.0;
    bool results_agree = true;
    std::string hardware_info;
};

// ── Backpropagation data ───────────────────────────────────────────────────────

struct NeuralNetParams {
    double w = 0.5;
    double b = 0.0;
    double v = 1.0;
    double c = 0.0;
    double x = 1.0;
    double y = 2.0;
    double alpha = 0.1;
};

struct ForwardResult {
    double h = 0.0;           // hidden activation tanh(wx+b)
    double y_hat = 0.0;       // output vh+c
    double loss = 0.0;        // 0.5*(y_hat - y)^2
    NeuralNetParams params;
};

struct GradientResult {
    double dJ_dw = 0.0;
    double dJ_db = 0.0;
    double dJ_dv = 0.0;
    double dJ_dc = 0.0;
    ForwardResult forward;
};

struct GradientVerification {
    double dJ_dw_analytical = 0.0, dJ_dw_numerical = 0.0, dJ_dw_error = 0.0;
    double dJ_db_analytical = 0.0, dJ_db_numerical = 0.0, dJ_db_error = 0.0;
    double dJ_dv_analytical = 0.0, dJ_dv_numerical = 0.0, dJ_dv_error = 0.0;
    double dJ_dc_analytical = 0.0, dJ_dc_numerical = 0.0, dJ_dc_error = 0.0;
    double max_error = 0.0;
    bool passed = false;       // max_error <= 1e-5
};

struct TrainingStep {
    int step = 0;
    double loss = 0.0;
    double y_hat = 0.0;
    NeuralNetParams params;
};

struct TrainingResult {
    std::vector<TrainingStep> history;
    NeuralNetParams final_params;
    double final_loss = 0.0;
    GradientVerification initial_verification;
};

// ── Hardware device data ───────────────────────────────────────────────────────

enum class DeviceStatus {
    Disconnected,
    Connecting,
    Connected,
    Error
};

inline std::string device_status_to_string(DeviceStatus s) {
    switch (s) {
        case DeviceStatus::Disconnected: return "Disconnected";
        case DeviceStatus::Connecting:   return "Connecting";
        case DeviceStatus::Connected:    return "Connected";
        case DeviceStatus::Error:        return "Error";
        default: return "Unknown";
    }
}

struct DeviceCapabilities {
    std::string name;
    std::string type;
    std::string firmware_version;
    std::vector<std::string> supported_protocols;
    int max_sample_rate_hz = 0;
    int adc_resolution_bits = 0;
    int gpio_pins = 0;
};

struct TelemetryData {
    double cpu_usage_percent = 0.0;
    double temperature_celsius = 0.0;
    double voltage_v = 0.0;
    double current_ma = 0.0;
    uint64_t uptime_seconds = 0;
    int free_memory_bytes = 0;
    std::string status_message;
};

struct DeviceInfo {
    std::string id;
    std::string name;
    std::string type;
    DeviceStatus status = DeviceStatus::Disconnected;
    std::optional<DeviceCapabilities> capabilities;
    std::optional<TelemetryData> telemetry;
};

} // namespace workbench

#endif // WORKBENCH_COMMON_TYPES_H
