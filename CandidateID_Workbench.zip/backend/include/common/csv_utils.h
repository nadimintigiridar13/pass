#ifndef WORKBENCH_COMMON_CSV_UTILS_H
#define WORKBENCH_COMMON_CSV_UTILS_H

#include <string>
#include <vector>
#include <unordered_map>
#include "common/types.h"

namespace workbench {
namespace csv {

struct CSVRow {
    std::vector<std::string> fields;

    const std::string& operator[](size_t idx) const { return fields[idx]; }
    size_t size() const { return fields.size(); }
};

struct CSVData {
    std::vector<std::string> headers;
    std::vector<CSVRow> rows;

    // Get column index by name, returns -1 if not found
    int column_index(const std::string& name) const;
    size_t num_rows() const { return rows.size(); }
    size_t num_cols() const { return headers.size(); }
};

// Parse CSV from string content
Result<CSVData> parse_csv(const std::string& content);

// Parse CSV from file
Result<CSVData> parse_csv_file(const std::string& filepath);

// Write CSV to string
std::string write_csv(const CSVData& data);

// Utility: trim whitespace
std::string trim(const std::string& s);

// Utility: split a line by delimiter
std::vector<std::string> split_line(const std::string& line, char delimiter = ',');

} // namespace csv
} // namespace workbench

#endif // WORKBENCH_COMMON_CSV_UTILS_H
