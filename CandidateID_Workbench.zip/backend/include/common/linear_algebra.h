#ifndef WORKBENCH_COMMON_LINEAR_ALGEBRA_H
#define WORKBENCH_COMMON_LINEAR_ALGEBRA_H

#include <vector>
#include <string>
#include "common/types.h"

namespace workbench {
namespace linalg {

// Dense matrix stored row-major
class Matrix {
public:
    Matrix();
    Matrix(size_t rows, size_t cols, double init_val = 0.0);

    size_t rows() const { return rows_; }
    size_t cols() const { return cols_; }

    double& operator()(size_t i, size_t j);
    const double& operator()(size_t i, size_t j) const;

    // Add value to element (for assembly)
    void add(size_t i, size_t j, double val);

    // Zero out row and column, set diagonal to 1 (for BCs)
    void apply_bc_row_col(size_t idx);

    // Get raw data
    const std::vector<double>& data() const { return data_; }
    std::vector<double>& data() { return data_; }

    // Debug print
    std::string to_string() const;

private:
    size_t rows_, cols_;
    std::vector<double> data_;
};

// Dense vector
class Vector {
public:
    Vector();
    explicit Vector(size_t n, double init_val = 0.0);

    size_t size() const { return data_.size(); }

    double& operator()(size_t i);
    const double& operator()(size_t i) const;
    double& operator[](size_t i);
    const double& operator[](size_t i) const;

    void add(size_t i, double val);

    const std::vector<double>& data() const { return data_; }
    std::vector<double>& data() { return data_; }

    std::string to_string() const;

private:
    std::vector<double> data_;
};

// ── Solvers ────────────────────────────────────────────────────────────────────

// Solve tridiagonal system using Thomas algorithm
// a = sub-diagonal, b = diagonal, c = super-diagonal, d = rhs
// Returns solution vector x
Result<Vector> solve_tridiagonal(Vector a, Vector b, Vector c, Vector d);

// General dense solver using Gaussian elimination with partial pivoting
Result<Vector> solve_dense(Matrix A, Vector b);

// ── Matrix/Vector operations ───────────────────────────────────────────────────

Vector matvec(const Matrix& A, const Vector& x);
double dot(const Vector& a, const Vector& b);
double norm(const Vector& v);
Vector add(const Vector& a, const Vector& b);
Vector subtract(const Vector& a, const Vector& b);
Vector scale(const Vector& v, double s);

} // namespace linalg
} // namespace workbench

#endif // WORKBENCH_COMMON_LINEAR_ALGEBRA_H
