#ifndef WORKBENCH_COMMON_VALIDATION_H
#define WORKBENCH_COMMON_VALIDATION_H

#include <string>
#include <cmath>
#include <limits>
#include <filesystem>

namespace workbench {
namespace validation {

// Numeric validation
bool is_finite(double v);
bool is_positive(double v);
bool is_non_negative(double v);
bool is_in_range(double v, double lo, double hi);
bool is_positive_integer(int v);

// String validation
bool is_non_empty(const std::string& s);

// File validation
bool file_exists(const std::string& path);
bool has_extension(const std::string& path, const std::string& ext);
std::string get_extension(const std::string& path);

// Thermal parameter validation
std::string validate_thermal_params(double L, double A, double k, double q,
                                     double T_left, double T_right, int num_elements);

// General number parsing
bool try_parse_double(const std::string& s, double& out);
bool try_parse_int(const std::string& s, int& out);

} // namespace validation
} // namespace workbench

#endif // WORKBENCH_COMMON_VALIDATION_H
