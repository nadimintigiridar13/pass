#ifndef WORKBENCH_THERMAL_THERMAL_SOLVER_H
#define WORKBENCH_THERMAL_THERMAL_SOLVER_H

#include "common/types.h"

namespace workbench {
namespace thermal {

// Solve 1D steady-state thermal problem using FEA
// -d/dx(kA dT/dx) = qA, with Dirichlet BCs
Result<ThermalResult> solve(const ThermalParams& params);

// Analytical solution: T(x) = T_left + (T_right - T_left)*x/L + q/(2k)*x*(L-x)
double analytical_solution(double x, const ThermalParams& params);

// Run convergence study with mesh sizes N = 10, 20, 40, 80
Result<ConvergenceResult> convergence_study(const ThermalParams& params);

} // namespace thermal
} // namespace workbench

#endif // WORKBENCH_THERMAL_THERMAL_SOLVER_H
