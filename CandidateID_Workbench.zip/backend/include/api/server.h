#ifndef WORKBENCH_API_SERVER_H
#define WORKBENCH_API_SERVER_H

#include <memory>
#include <string>
#include "hardware/microcontroller_adapter.h"
#include "hardware/fpga_adapter.h"
#include "hardware/jtag_adapter.h"

namespace httplib {
    class Server;
}

namespace workbench {
namespace api {

class APIServer {
public:
    APIServer(int port = 8080);
    ~APIServer();

    bool start();
    void stop();

private:
    void setup_routes();
    void setup_cors();

    int port_;
    std::unique_ptr<httplib::Server> server_;

    // Hardware adapters state
    hardware::MicrocontrollerAdapter esp32_adapter_;
    hardware::FPGABoardAdapter fpga_adapter_;
    hardware::JTAGAdapter jtag_adapter_;
};

} // namespace api
} // namespace workbench

#endif // WORKBENCH_API_SERVER_H
