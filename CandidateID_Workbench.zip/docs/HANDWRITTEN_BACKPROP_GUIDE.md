# HANDWRITTEN CALCULATION SHEET GUIDE
## Task F: Step-by-Step Backpropagation Derivation
**PASS SCIENCE WORKS | R&D Internship 2026–2027**  
*Instruction: Copy the exact step-by-step mathematical derivation below by hand onto two sheets of paper and photograph them for the submission appendix.*

---

### PAGE 1 OF 2

#### 1. Problem Definition & Network Equations
- **Single Training Sample**:
  $$x = 1.0, \quad \text{Target } y = 2.0$$
- **Network Equations**:
  - Hidden Pre-activation: $z = w \cdot x + b$
  - Hidden Activation: $h = \tanh(z)$
  - Output Prediction: $\hat{y} = v \cdot h + c$
  - Quadratic Loss: $J = \frac{1}{2} (\hat{y} - y)^2$
- **Initial Parameter Values ($t = 0$)**:
  $$w = 0.5, \quad b = 0.0, \quad v = 1.0, \quad c = 0.0$$
- **Learning Rate**: $\alpha = 0.1$

---

#### 2. Manual Forward Propagation (at $t = 0$)
1. Pre-activation $z$:
   $$z = w \cdot x + b = (0.5)(1.0) + 0.0 = 0.5$$
2. Hidden Layer Activation $h$:
   $$h = \tanh(0.5) = \frac{e^{0.5} - e^{-0.5}}{e^{0.5} + e^{-0.5}} \approx 0.462117$$
3. Predicted Output $\hat{y}$:
   $$\hat{y} = v \cdot h + c = (1.0)(0.462117) + 0.0 = 0.462117$$
4. Prediction Error $e$:
   $$e = \hat{y} - y = 0.462117 - 2.0 = -1.537883$$
5. Initial Objective Loss $J$:
   $$J = \frac{1}{2} (\hat{y} - y)^2 = \frac{1}{2} (-1.537883)^2 = \frac{1}{2}(2.365084) \approx 1.182542$$

---

#### 3. Derivation of Gradients via Chain Rule
We apply the chain rule of calculus backwards from the scalar loss $J$:
- Derivative of loss with respect to output:
  $$\frac{\partial J}{\partial \hat{y}} = \frac{\partial}{\partial \hat{y}} \left[ \frac{1}{2}(\hat{y} - y)^2 \right] = (\hat{y} - y) = e$$

##### Output Layer Gradients ($v, c$):
1. **With respect to output bias $c$**:
   $$\frac{\partial J}{\partial c} = \frac{\partial J}{\partial \hat{y}} \cdot \frac{\partial \hat{y}}{\partial c} = (\hat{y} - y) \cdot 1 = -1.537883$$
2. **With respect to output weight $v$**:
   $$\frac{\partial J}{\partial v} = \frac{\partial J}{\partial \hat{y}} \cdot \frac{\partial \hat{y}}{\partial v} = (\hat{y} - y) \cdot h = (-1.537883) \cdot (0.462117) = -0.710682$$

---

### PAGE 2 OF 2

##### Hidden Layer Gradients ($w, b$):
1. **Backpropagated error to hidden activation $h$**:
   $$\frac{\partial J}{\partial h} = \frac{\partial J}{\partial \hat{y}} \cdot \frac{\partial \hat{y}}{\partial h} = (\hat{y} - y) \cdot v$$
2. **Derivative of activation function $\tanh(z)$**:
   $$\frac{d}{dz}[\tanh(z)] = 1 - \tanh^2(z) = 1 - h^2$$
   Numerical value of activation derivative:
   $$1 - h^2 = 1 - (0.462117)^2 = 1 - 0.213552 = 0.786448$$
3. **Pre-activation gradient $\frac{\partial J}{\partial z}$**:
   $$\frac{\partial J}{\partial z} = \frac{\partial J}{\partial h} \cdot \frac{dh}{dz} = (\hat{y} - y) \cdot v \cdot (1 - h^2)$$
   $$\frac{\partial J}{\partial z} = (-1.537883) \cdot (1.0) \cdot (0.786448) = -1.209464$$
4. **With respect to input weight $w$**:
   $$\frac{\partial J}{\partial w} = \frac{\partial J}{\partial z} \cdot \frac{\partial z}{\partial w} = \frac{\partial J}{\partial z} \cdot x = (-1.209464) \cdot 1.0 = -1.209464$$
5. **With respect to input bias $b$**:
   $$\frac{\partial J}{\partial b} = \frac{\partial J}{\partial z} \cdot \frac{\partial z}{\partial b} = \frac{\partial J}{\partial z} \cdot 1.0 = -1.209464$$

---

#### 4. Simultaneous Gradient Descent Update
Using learning rate $\alpha = 0.1$:
$$\theta_{\text{new}} = \theta - \alpha \frac{\partial J}{\partial \theta}$$

1. **Input Weight $w$**:
   $$w_{\text{new}} = 0.5 - (0.1)(-1.209464) = 0.5 + 0.120946 = 0.620946$$
2. **Input Bias $b$**:
   $$b_{\text{new}} = 0.0 - (0.1)(-1.209464) = 0.0 + 0.120946 = 0.120946$$
3. **Output Weight $v$**:
   $$v_{\text{new}} = 1.0 - (0.1)(-0.710682) = 1.0 + 0.071068 = 1.071068$$
4. **Output Bias $c$**:
   $$c_{\text{new}} = 0.0 - (0.1)(-1.537883) = 0.0 + 0.153788 = 0.153788$$

---

#### 5. Gradient Direction Analysis
Because $\hat{y} = 0.462 < 2.0$, the network under-predicted the target, resulting in a negative prediction error $e = -1.538$. Consequently, all four partial derivatives $\frac{\partial J}{\partial \theta}$ are negative. Subtracting these negative quantities increases all weights and biases, which directly increases $\hat{y}$ on subsequent forward passes, successfully minimizing the error.
